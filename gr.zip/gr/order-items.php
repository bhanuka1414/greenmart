<?php session_start(); ?>
<?php 
    if (!isset($_SESSION["uid"])) {
        header('LOCATION:http://www.greenmart.cf/');
    }
 ?>
<?php require_once('inc/sql_con.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Rammetto+One" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/main.css">
    <link rel="shortcut icon" href="img/Artdesigner-Urban-Stories-Cart.ico" />
    <script src="bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="bootstrap/js/main.js"></script>
	<title>Item</title>
</head>
<body>
	<?php require_once('inc/top_nav.php'); ?>
    <div class="container">
	<h5>ORDER NO : <?php echo "{$_GET['orid']}"; ?></h5>
		<div class="table-responsive">
	<table class="table table-striped" style="text-align: center;">
    <thead>
      <tr>
        <th class="text-center">ITEM</th>
        <th class="text-center">QTY</th>
        <th class="text-center">PRICE</th>
      </tr>
    </thead>
    <tbody>
    <?php 
        $sql="SELECT * FROM order_item WHERE order_id={$_GET['orid']}";
        $res=mysqli_query($con, $sql);
        while ($row1=mysqli_fetch_assoc($res))
        {
            $sq2="SELECT * FROM products WHERE  id={$row1['item_id']}";
            $res2=mysqli_query($con, $sq2);
            $row2=mysqli_fetch_assoc($res2);
     ?>
      <tr>
        <td style="max-width: 150px;">
        <span><?php echo '<img class="img-responsive hidden-xs" style="max-width: 100px; max-height:100px; float: left;" src="data:image/jpeg;base64,'.base64_encode( $row2['img'] ).'"/>'; ?></span>
        <span class="hidden-xs" style="max-width: 100%; display: block; overflow-y: scroll; max-height: 100px;">
        <?php echo "{$row2['p_dis']}"; ?></span>
        <p class="hidden-lg hidden-md hidden-sm"><?php echo "{$row2['p_name']}"; ?></p>
        </td>
        <td><?php echo "{$row1['qty']}"; ?></td>
        <td><?php echo "{$row1['qty']}"; ?> x <?php echo "{$row2['p_price']}"; ?> <span class="glyphicon glyphicon-triangle-right"></span> RS <?php echo "{$row1['price']}"; ?>.</td>
        
      </tr>
      <?php } ?>
    </tbody>
  </table>
  
		</div>
        

		<div class="row">
            <div class="col-md-offset-11 col-md-1 col-sm-offset-11 col-sm-1">
            <a href="http://www.greenmart.cf/my-orders.php" class="btn btn-success pull-right">Back</a>
            </div>      
        </div>

	</div>

        <!--footer-->
    <?php require_once('inc/footer.php'); ?>
</body>
</html>