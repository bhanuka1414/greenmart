<?php session_start(); ?>
<?php require_once('../inc/sql_con.php'); ?>
<?php 
    if (!isset($_SESSION["admin"])) {
        header('LOCATION:http://www.greenmart.cf/admin/');
    }
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/main.css">
    <link rel="shortcut icon" href="../img/Artdesigner-Urban-Stories-Cart.ico" />
    <script src="../bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/main.js"></script>
	<title>Admin</title>
	<style>
@media screen and (max-width: 750px)
{
    
    body { padding-top: 0px; }
   
}
body { padding-top: 0px; }

    </style>
</head>
<body>
<?php require_once('../inc/admin_tmp.php'); ?>
<br><br>
    <div class="container">
        <hr>
    <center><h3>Edit Product</h3></center>
        <hr>
    </div>
<?php 
    if (isset($_GET['pid'])) {
        $sql="SELECT * FROM products WHERE id={$_GET['pid']}";
        $res=mysqli_query($con, $sql);
        $row=mysqli_fetch_assoc($res);
    }
 ?>
 <?php 
    if (isset($_POST['up_b'])) {
        date_default_timezone_set('Asia/Kolkata');
        $date1=date('Y-m-d H:i:s');
        if (isset($_POST['con_img']) && $_POST['con_img']==1)
        {
           if (isset($_FILES['img']) && $_FILES['img']['size'] > 0) {
                //if ($_FILES['img']['size']<2000000){
                    $tmpName = $_FILES['img']['tmp_name'];
                    $fp = fopen($tmpName, 'r');
                    $data = fread($fp, filesize($tmpName));
                    $data = addslashes($data);
                    fclose($fp);
            

//visible = 0 -> show product
 //visible = 1 -> hide product                   
                    if (isset($_POST['vis']) && $_POST['vis']==2) {
                        $sql="UPDATE products SET 
                        p_name='{$_POST['pname']}',p_dis='{$_POST['pdis']}',p_price={$_POST['pprice']},
                        img='{$data}',visible=0,qty_up_date='{$date1}',qty=(qty+{$_POST['qty']}) WHERE id={$_POST['pnoup']}";
                    }
                    else
                    {
                        $sql="UPDATE products SET 
                        p_name='{$_POST['pname']}',p_dis='{$_POST['pdis']}',p_price={$_POST['pprice']},
                        img='{$data}',visible=1,qty_up_date='{$date1}',qty=(qty+{$_POST['qty']}) WHERE id={$_POST['pnoup']}";
                    }
                //}
                //else{echo "<script>alert('please select image(size between 1 to 200kb)!')</script>";}
            }else{echo "<script>alert('please select image(size between 1 to 200kb)!')</script>";}

        }
        else
        {
            if (isset($_POST['vis']) && $_POST['vis']==2) {
                $sql="UPDATE products SET 
                        p_name='{$_POST['pname']}',p_dis='{$_POST['pdis']}',p_price={$_POST['pprice']},visible=0,qty_up_date='{$date1}',qty=(qty+{$_POST['qty']}) WHERE id={$_POST['pnoup']}";
            }
            else
            {
                $sql="UPDATE products SET 
                        p_name='{$_POST['pname']}',p_dis='{$_POST['pdis']}',p_price={$_POST['pprice']},visible=1,qty_up_date='{$date1}',qty=(qty+{$_POST['qty']}) WHERE id={$_POST['pnoup']}";
            }
        }
        $res=mysqli_query($con, $sql);
        $sql="SELECT * FROM products WHERE id={$_POST['pnoup']}";
        $res=mysqli_query($con, $sql);
        $row=mysqli_fetch_assoc($res);
        unset($_POST);
    }
  ?>
  <?php 
        if ($row['visible']==0) {//display status
            $v="visible";
        }
        else
        {
            $v="disabled";
        }
   ?>
<div class="container" style="background-color: #EAEDED; border-radius: 7px;">
    <form action="" method="post" enctype="multipart/form-data">
        <div class="row">
            <div class="col-md-8" style="background-color: #EAEDED; border-radius: 7px;">
            <div style="margin: 20px; background-color: #F8F9F9; padding: 10px; border-radius: 7px;">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="form-group">
                            <label for="inputlg">Product Name:</label>
                            <input required class="form-control" id="inputlg" type="text" name="pname" value="<?php echo "{$row['p_name']}"; ?>">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12">
                        <div class="form-group">
                            <label for="pdis">Discription:</label>
                            <textarea required class="form-control" rows="12" id="pdis" name="pdis" maxlength="300"><?php echo "{$row['p_dis']}"; ?></textarea>
                        </div>
                    </div>
                </div> 
                </div>
                <div style="margin: 20px; background-color: #F8F9F9; padding: 10px; border-radius: 7px;">
                <div class="row">
                    <div class="col-xs-12">
                    <div class="form-group">
                            <label>Current Image:</label>
                    <center>
                    <?php echo '<img class="img-rounded img-responsive" style="max-height: 450px; width: auto;" src="data:image/jpeg;base64,'.base64_encode( $row['img'] ).'"/>'; ?></center>
                    <br>
                            <div class="checkbox">
                                <label><input type="checkbox" value="1" name="con_img">Confirm Image</label>
                            </div>
                    <label for="inputlg">Select Image:</label>
                            <input class="form-control" id="inputlg" type="file" name="img">
                    </div>
                    </div>
                </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="row" style="margin: 20px; background-color: #F8F9F9; opacity: 0.9; padding: 10px; border-radius: 7px;">
                    <div class="col-md-12">
                        <fieldset id="name1" class=" col-md-12">

                        <legend>visibility:(<?php echo "{$v}"; ?>)</legend>
                        <div>           
                            <div class="checkbox">
                             <label><input type="checkbox" name="vis" value="2" checked>Product Visible</label>
                            </div>
                        </div>    
                        </fieldset>
                    </div>
                </div>
                <div class="row" style="margin: 20px; background-color: #F8F9F9; opacity: 0.9; padding: 10px; border-radius: 7px;">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="inputlg">Price:</label>
                            <div class="input-group">
                                <span class="input-group-addon">RS</span>   
                                <input type="text" id="pprice" name="pprice" required value="<?php echo "{$row['p_price']}"; ?>" class="form-control" >
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row" style="margin: 20px; background-color: #F8F9F9; opacity: 0.9; padding: 10px; border-radius: 7px;">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="inputlg">Update QTY:(<?php echo "{$row['qty']}"; ?>)</label>
                            <input class="form-control" id="inputlg" type="number" name="qty" value="0" required placeholder="qty + new qty">
                        </div>
                    </div>
                </div>
                <div class="row" style="margin: 20px; background-color: #F8F9F9; opacity: 0.9; padding: 10px; border-radius: 7px;">
                    <div class="col-md-12">
                    <input type="hidden" name="pnoup" value="<?php echo "{$row['id']}"; ?>">
                        <div class="form-group">
                            <button class="form-control btn btn-primary" type="submit" name="up_b">UPDATE</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form> 
</div>
<br><br>
</body>
</html>



