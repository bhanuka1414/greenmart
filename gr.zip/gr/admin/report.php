<?php session_start(); ?>
<?php require_once('../inc/sql_con.php'); ?>
<?php 
    if (!isset($_SESSION["admin"])) {
        header('LOCATION:http://www.greenmart.cf/admin/');
    }
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/main.css">
    <link rel="shortcut icon" href="../img/Artdesigner-Urban-Stories-Cart.ico" />
    <script src="../bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/main.js"></script>
	<title>Admin</title>
	
    <style>
@media screen and (max-width: 750px)
{
    
    body { padding-top: 0px; }
   #tot_income {z-index: 2;  bottom: 10px; position: fixed; left: 5px;}
}
body { padding-top: 0px; }
#tot_income {z-index: 2;bottom: 5px;position: fixed;  width: 100%;}

    </style>
</head>
<body>
<?php require_once('../inc/admin_tmp.php'); ?>
<br><br>
<div class="container">
<center><h3>SALES REPORT</h3></center>
<div class="row">
<div class="col-md-4">
    <form action="" method="get">
                <div class="row" style="margin: 20px; background-color: #F8F9F9; opacity: 0.9; padding: 10px; border-radius: 7px;">
                    <div class="col-md-12">
                        <div class="radio">
                            <label><input type="radio" name="s" value="az">Name A to Z</label>
                        </div>
                        <div class="radio">
                            <label><input type="radio" name="s" value="za">Name Z to A</label>
                        </div>
                    </div>
                </div>

                <div class="row" style="margin: 20px; background-color: #F8F9F9; opacity: 0.9; padding: 10px; border-radius: 7px;">
                    <div class="col-md-12">
                        <div class="form-group">
                               
                                <input type="number" name="date" placeholder="Date"  class="form-control" >
                            
                        </div>
                    </div>
                </div>

                <div class="row" style="margin: 20px; background-color: #F8F9F9; opacity: 0.9; padding: 10px; border-radius: 7px;">
                    <div class="col-md-12">
                        <div class="form-group">
                               
                                <label for="sel1">Month:</label>
                            <select class="form-control" name="month" id="sel1">
                                <option value="0">SELECT MONTH</option>
                                <option value="1">January</option>
                                <option value="2">February</option>
                                <option value="3">March</option>
                                <option value="4">April</option>
                                <option value="5">May</option>
                                <option value="6">June</option>
                                <option value="7">July</option>
                                <option value="8">August</option>
                                <option value="9">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                            </select>
                            
                        </div>
                    </div>
                </div>

                <div class="row" style="margin: 20px; background-color: #F8F9F9; opacity: 0.9; padding: 10px; border-radius: 7px;">
                    <div class="col-md-12">
                        <div class="form-group">
                               
                                <input type="number" name="year" value="2017" placeholder="Year"  class="form-control" >
                            
                        </div>
                    </div>
                </div>

                <div class="row" style="margin: 20px; background-color: #F8F9F9; opacity: 0.9; padding: 10px; border-radius: 7px;">
                    <div class="col-md-12">
                        <div class="form-group">
                            <button class="form-control btn btn-primary" type="submit" name="sub1">Generate Report</button>
                        </div>
                    </div>
                </div>
       </form>         
    </div>
    <div class="col-md-8">
    <div class="row text-center hidden-xs hidden-sm" style="border-bottom: 1px solid black;"><hr>
        <div class="col-md-3">
            <h5>PRODUCT ID</h5>
        </div>
        <div class="col-md-3">
            <h5>PRODUCT NAME</h5>
        </div>
        <div class="col-md-3">
            <h5>SOLD QUANTITY</h5>
        </div>
        <div class="col-md-3">
            <h5>TOTAL AMOUNT</h5>
        </div>
       
    </div>
        <br>
        <?php 
        $qty_tot=0;
        $p_tot=0;
        $total=0;
        $total_q=0;
        

     ?>

<?php 

if (isset($_REQUEST['s'])) 
{
    

    switch ($_REQUEST['s']) 
    {
        case 'az':
            $sql_all="SELECT * FROM products ORDER BY p_name";//sort a-z
            break;
        case 'za':
            $sql_all="SELECT * FROM products ORDER BY p_name DESC";//sort z-a
            break;
        
        default:
            $sql_all="SELECT * FROM products";//default
            break;
    }
}
else
{
    $sql_all="SELECT * FROM products";//default not set radio button
}


    
    $result_all=mysqli_query($con, $sql_all);
    while ($row_all=mysqli_fetch_assoc($result_all)) //while end of products
    {
        $pname=$row_all['p_name'];
        $pi=$row_all['id'];
    
if (isset($_REQUEST['date']) && $_REQUEST['date']!=0) //only set date
{
    $sql="SELECT * FROM order_item JOIN orders ON order_item.order_id = orders.order_id WHERE order_item.item_id={$pi} AND orders.date1={$_REQUEST['date']}";
    if (isset($_REQUEST['month']) && $_REQUEST['month']!=0) //set date and month
    {
        $sql="SELECT * FROM order_item JOIN orders ON order_item.order_id = orders.order_id WHERE order_item.item_id={$pi} AND orders.date1={$_REQUEST['date']} AND 
        orders.month={$_REQUEST['month']}";
        if (isset($_REQUEST['year']) && $_REQUEST['year']!=0) //set date month year
        {
            $sql="SELECT * FROM order_item JOIN orders ON order_item.order_id = orders.order_id WHERE order_item.item_id={$pi} AND orders.date1={$_REQUEST['date']} AND 
    orders.month={$_REQUEST['month']} AND orders.year={$_REQUEST['year']}";
        }
        
    }
}
else
{
    if (isset($_REQUEST['month']) && $_REQUEST['month']!=0) //set only month
    {
        $sql="SELECT * FROM order_item JOIN orders ON order_item.order_id = orders.order_id WHERE order_item.item_id={$pi} AND orders.month={$_REQUEST['month']}";
        if (isset($_REQUEST['year']) && $_REQUEST['year']!=0)//month and year
        {
            $sql="SELECT * FROM order_item JOIN orders ON order_item.order_id = orders.order_id WHERE order_item.item_id={$pi} AND orders.month={$_REQUEST['month']} AND orders.year={$_REQUEST['year']}";
        }
    }
    else
    {
        if (isset($_REQUEST['year']) && $_REQUEST['year']!=0)//only year
        {
            $sql="SELECT * FROM order_item JOIN orders ON order_item.order_id = orders.order_id WHERE order_item.item_id={$pi} AND orders.year={$_REQUEST['year']}";
        }
        else
        {
            $sql="SELECT * FROM order_item JOIN orders ON order_item.order_id = orders.order_id WHERE order_item.item_id={$pi}";//on select(page onload)
        }
        
    }
    
}
    
    $result=mysqli_query($con, $sql);
    

    while ($rows=mysqli_fetch_assoc($result)) 
    {
        

            /*$year=$rows['year'];
            $month=$rows['month'];
            $day=$rows['date1'];
            $time=$rows['time1'];
            $date="{$day}-{$month}-{$year} {$time}";*/

        $qty=$rows['qty'];
        $total_am=$rows['price'];

        $qty_tot+=$qty; //calculate item  total qty
        $p_tot+=$total_am; // calculate total amount

    /*  $sql1="SELECT * FROM products WHERE id={$pid}";
        $result1=mysqli_query($con, $sql1);
        $row=mysqli_fetch_assoc($result1);

        $name=$row['p_name']; */

    
    }
 ?>
    <div class="row text-center" style="border: 1px solid #D5D8DC; border-radius: 7px;">
        <div class="col-md-3">
            <h6 class="text-left hidden-md hidden-lg">ID:</h6><p><?php echo "{$pi}"; ?></p>
        </div>
        <div class="col-md-3">
            <h6 class="text-left hidden-md hidden-lg">NAME:</h6><p><?php echo "{$pname}"; ?></p>
        </div>
        <div class="col-md-3">
            <h6 class="text-left hidden-md hidden-lg">QUANTITY:</h6><p><?php echo "{$qty_tot}"; ?></p>
        </div>
        <div class="col-md-3">
            <h6 class="text-left hidden-md hidden-lg">AMOUNT:</h6><p><?php echo "{$p_tot}"; ?></p>
        </div>
        <?php 
            $total+=$p_tot;
            $total_q+=$qty_tot;
             ?>
    </div><br><br>
    <?php 


$qty_tot=0;
    $p_tot=0;
    

} ?>

<div class="" id="tot_income">
    <span class="label label-default" style="font-size: 11pt;">Sold quantity: <?php echo "{$total_q}"; ?></span> 
    <span class="label label-default" style="font-size: 11pt;">Total Income: RS <?php echo "{$total}"; ?></span>
</div>
    </div>
    
</div>
</div>
</body>
</html>

