<?php require_once('../inc/sql_con.php'); ?>
<?php 
	if(isset($_GET['opt']) && $_GET['opt']="new"){ //this for desplaing new orders (admin/index.php)
    $sql="SELECT * FROM orders WHERE confirm=0 ORDER BY order_id DESC";
    $res=mysqli_query($con, $sql);
    while ($row=mysqli_fetch_assoc($res)) {
        $sql1="SELECT * FROM user WHERE id={$row['cid']}";
        $res1=mysqli_query($con, $sql1);
        $row1=mysqli_fetch_assoc($res1)
        ?>
 		<?php $date="{$row["date1"]} / {$row["month"]} / {$row["year"]}   {$row["time1"]}"; ?>
<?php  		
		echo '
		<div class="row text-center" style="border: 1px solid #D5D8DC; border-radius: 7px;">
		<div class="col-md-2">
		<h6 class="text-left hidden-md hidden-lg">ORDER NO:</h6><p>'.$row['order_id'].'</p>
		</div>
		<div class="col-md-2">
		<h6 class="text-left hidden-md hidden-lg">DATE:</h6><p>'.$date.'</p>
		</div>
		<div class="col-md-1">
		<h6 class="text-left hidden-md hidden-lg">TOTAL AMOUNT:</h6><p>RS '.$row['total_am'].'</p>
		</div>
        <div class="col-md-2">
        <h6 class="text-left hidden-md hidden-lg">ADDRESS:</h6><p>'.$row1['address'].'</p>
        </div>
        <div class="col-md-1">
        <h6 class="text-left hidden-md hidden-lg">PHONE NO:</h6><p>'.$row1['phone'].'</p>
        </div>
        <div class="col-md-2">
        <h6 class="text-left hidden-md hidden-lg">NAME:</h6><p>'.$row1['l_name'].'</p>
        </div>
        <div class="col-md-2">
        <a href="http://www.greenmart.cf/admin/order-item-confirm.php?orid='.$row['order_id'].'" class="btn btn-primary">View Order</a >
        </div>
    </div>
    <br>
		';
	}	}
 ?>

