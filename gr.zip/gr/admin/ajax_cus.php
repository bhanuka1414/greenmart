<?php session_start(); ?>
<?php require_once('../inc/sql_con.php'); ?>
<?php 
	if (isset($_GET['opt']) && $_GET['opt']=="cs") { //search
		$sql="SELECT * FROM user WHERE id LIKE '%{$_GET['sv']}%' OR f_name LIKE '%{$_GET['sv']}%' OR 
		l_name LIKE '%{$_GET['sv']}%' OR phone LIKE '%{$_GET['sv']}%' OR
		email LIKE '%{$_GET['sv']}%' ";
	}
	else if(isset($_GET['opt']) && $_GET['opt']="c" || $_GET['sv']=="")//onload ro empty search value
	{
		$sql="SELECT * FROM user";
	}
	$res=mysqli_query($con, $sql);
		while ($row=mysqli_fetch_assoc($res)) 
		{
			if ($row['gender']=='m') {
				$gender="Male";
			}
			else if($row['gender']=='f')
			{
				$gender="Female";
			}
			echo '
		<div class="row text-center" style="border: 1px solid #D5D8DC; border-radius: 7px;">
		<div class="col-md-1">
		<h6 class="text-left hidden-md hidden-lg">ID:</h6><p>'.$row['id'].'</p>
		</div>
		<div class="col-md-2">
		<h6 class="text-left hidden-md hidden-lg">First Name:</h6><p>'.$row['f_name'].'</p>
		</div>
		<div class="col-md-2">
		<h6 class="text-left hidden-md hidden-lg">Last Name:</h6><p>'.$row['l_name'].'</p>
		</div>
        <div class="col-md-1">
		<h6 class="text-left hidden-md hidden-lg">Gender:</h6><p>'.$gender.'</p>
		</div>
        <div class="col-md-2">
        <h6 class="text-left hidden-md hidden-lg">Address:</h6><p>'.$row['address'].'</p>
        </div>
        <div class="col-md-2">
        <h6 class="text-left hidden-md hidden-lg">E-mail:</h6><p>'.$row['email'].'</p>
        </div>
        <div class="col-md-2">
        <h6 class="text-left hidden-md hidden-lg">Phone NO:</h6><p>'.$row['phone'].'</p>
        </div>
    </div>
    <br>
		';
}
 ?>