<div class="navbar navbar-default sec-nav" style="height: 120px; margin-bottom: 0; padding-bottom: 0;">
            <a href="http://localhost/greenmart/" class="navbar-brand hidden-xs"><img src="http://localhost/greenmart/img/logo.png" alt=""></a>
            <img src="http://localhost/greenmart/img/track.png" alt="" class="nav navbar-btn btn-success navbar-left hidden-sm hidden-xs" style="margin-top: 50px; margin-left: 20px; border: 0px solid black; border-radius: 7px; text-decoration: none; position: absolute; width: 70%;">
            <form class="form-search" action="http://localhost/greenmart/search.php" method="POST">
                <div class="input-group navbar-right searchbox" style="margin-right: 1px; max-width: 50%; margin-top: 10px;">
                    <input type="search" class="form-control" placeholder="search..." name="search">
                    <span class="input-group-btn">
                        <button type="submit" name="sb" class="btn btn-success">Search</button>
                    </span>
                </div>
            </form>
        </div>