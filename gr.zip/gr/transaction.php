
<?php require_once('inc/sql_con.php'); ?>
<?php session_start(); ?>

<?php 
$orderid;
	
		date_default_timezone_set('Asia/Kolkata');
		
		
		$year=date('Y');
		$month=date('m');
		$date=date('d');
		$time=date('H:i');
		$oid1=date('dmYHis');
		$orderid=$_SESSION['uid'].$oid1;
		
		if ($_GET['ta'] == 0) 
		{
			header('Location:cart.php');
		}
		else
		{
			if ($_GET['loc']=='cl') {//current location order insert
				$sql="INSERT INTO orders(order_id,cid,year,month,date1,time1,total_am,confirm,remove,feedback,tmp_lat,tmp_lon,payment_type)VALUES({$orderid},
					{$_SESSION['uid']},{$year},{$month},{$date},'{$time}',{$_GET['ta']},0,0,'nof',{$_GET['lat']},{$_GET['lon']},'cash');";
				$res= mysqli_query ($con, $sql); //end 

				$sql2="SELECT * FROM cart WHERE cid={$_SESSION['uid']}";
				$res2=mysqli_query($con, $sql2);
					while ($row=mysqli_fetch_assoc($res2))//while end of cart
					{
			
						$sql3="INSERT INTO order_item(item_id,order_id,qty,price)VALUES({$row['pid']},{$orderid},{$row['qty']},{$row['tp']})";  //insert to order items
						$res3=mysqli_query($con, $sql3);

						$sql5="UPDATE products SET qty=(qty-{$row['qty']}),sold=(sold+{$row['qty']}) WHERE id={$row['pid']}";// reduce stock
						$results4 = mysqli_query($con, $sql5);
			
			
					}//end while
			$sql="DELETE FROM cart WHERE cid={$_SESSION['uid']}";
			$res4=mysqli_query($con, $sql);
			echo "1";
				}
				else if ($_GET['loc']=='h') {//home location
					$sql="SELECT loc_lat,loc_lon FROM user WHERE id={$_SESSION['uid']}";//get location fron db
					$res=mysqli_query($con, $sql);
					$row=mysqli_fetch_assoc($res);
						$sql="INSERT INTO orders(order_id,cid,year,month,date1,time1,total_am,confirm,remove,feedback,tmp_lat,tmp_lon,payment_type)VALUES
						({$orderid},
					{$_SESSION['uid']},{$year},{$month},{$date},'{$time}',{$_GET['ta']},0,0,'nof',{$row['loc_lat']},{$row['loc_lon']},'cash');";
				$res= mysqli_query ($con, $sql); //end 

				$sql2="SELECT * FROM cart WHERE cid={$_SESSION['uid']}";
				$res2=mysqli_query($con, $sql2);
					while ($row=mysqli_fetch_assoc($res2))//while end of cart
					{
			
						$sql3="INSERT INTO order_item(item_id,order_id,qty,price)VALUES({$row['pid']},{$orderid},{$row['qty']},{$row['tp']})";  //insert to order items
						$res3=mysqli_query($con, $sql3);

						$sql5="UPDATE products SET qty=(qty-{$row['qty']}),sold=(sold+{$row['qty']}) WHERE id={$row['pid']}";// reduce stock
						$results4 = mysqli_query($con, $sql5);
			
			
					}//end while
			$sql="DELETE FROM cart WHERE cid={$_SESSION['uid']}";
			$res4=mysqli_query($con, $sql);
			header('Location:http://www.greenmart.cf/my-orders.php');
				}
			
		}


 ?>
 <?php mysqli_close($con); ?>
