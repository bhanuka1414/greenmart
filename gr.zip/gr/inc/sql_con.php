<?php 

 $con = mysqli_connect('localhost','id1810074_root','Naji19970103','id1810074_greenmart');
 if(!$con)
 {
 	echo "<script>alert('connection_error');</script>";
 }

 ?>