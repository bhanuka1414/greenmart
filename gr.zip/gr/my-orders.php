<?php session_start(); ?>
<?php 
    if (!isset($_SESSION["uid"])) {
        header('LOCATION:http://www.greenmart.cf/');
    }
 ?>
<?php require_once('inc/sql_con.php'); ?>
<?php
    if (isset($_POST['feed-sub']))
    {
        $sqlup="UPDATE orders SET feedback='{$_POST['feed']}' WHERE order_id={$_POST['order-id']}";
        $res=mysqli_query($con, $sqlup);
        if ($res) {
            echo "<script>alert('Thank you for having taken your time to provide us with your valuable feedback')</script>";
            
        }

    }
//remove order by user
    if (isset($_GET['delete'])) {
        $sqlup1="UPDATE orders SET remove=1 WHERE order_id={$_GET['delete']}";
        $res1=mysqli_query($con, $sqlup1);
    }
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Rammetto+One" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/main.css">
    <link rel="shortcut icon" href="img/Artdesigner-Urban-Stories-Cart.ico" />
    <script src="bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="bootstrap/js/main.js"></script>
	<title>Item</title>
</head>
<body>
	<?php require_once('inc/top_nav.php'); ?>
    <div class="container">
        
<br>
	<div class="row hidden-xs">
        <div class="col-sm-2">
            <h6 class="text-center">ORDER NO</h6>
        </div>
        <div class="col-sm-2">
            <h6 class="text-center">DATE</h6>
        </div>
        <div class="col-sm-2">
            <h6 class="text-center">AMOUNT</h6>
        </div>
        <div class="col-sm-4">
            <h6 class="text-center">FEEDBACK</h6>
        </div>
        <div class="col-sm-2">
            <h6 class="text-center">ACTION</h6>
        </div>
    </div>
<br>
<?php 
    $sql="SELECT * FROM orders WHERE cid={$_SESSION["uid"]} AND remove=0 ORDER BY order_id DESC ";
    $res=mysqli_query($con, $sql);
    while ($row=mysqli_fetch_assoc($res)) {
        if ($row['feedback'] != "nof") {
            echo "<script>
                    $(function(){
                        $('#feed{$row['order_id']}').prop('disabled', true);
                        $('#feed-sub{$row['order_id']}').prop('disabled', true);
                    });
                  </script>";
        }
 ?>
 
 
    <div class="row" style="border: 1px solid #ABB2B9;">
        <div class="col-sm-2">
            <h6 class="text-left hidden-sm hidden-md hidden-lg">ORDER NO:</h6><p class="text-center">
            <?php echo "{$row['order_id']}"; ?></p>
        </div>
        <div class="col-sm-2">
            <h6 class="text-left hidden-sm hidden-md hidden-lg">DATE:</h6><p class="text-center">
            <?php echo "{$row['date1']}-{$row['month']}-{$row['year']}  {$row['time1']}"; ?></p>
        </div>
        <div class="col-sm-2">
            <h6 class="text-left hidden-sm hidden-md hidden-lg">AMOUNT:</h6><p class="text-center">
            RS <?php echo "{$row['total_am']}"; ?></p>
        </div>
        <div class="col-sm-3">
            <form action="" method="post">
                <textarea required class="form-control form-rounded" name="feed" id="feed<?php echo "{$row['order_id']}"; ?>" cols="35" rows="3" placeholder="feedback..."></textarea>
                <input type="hidden" name="order-id" value="<?php echo "{$row['order_id']}"; ?>">
                <button type="submit" name="feed-sub" id="feed-sub<?php echo "{$row['order_id']}"; ?>" class="btn btn-success" style="font-size: 10px; max-width: 70px; max-height: 20px; padding: 0;">Submit
                <span class="glyphicon glyphicon-circle-arrow-right"></span></button>
            </form>
        </div>
        <div class="col-sm-3" style="padding-bottom: 10px; padding-top: 10px;">
        <a href="http://www.greenmart.cf/tracking.php?orid=<?php echo "{$row['order_id']}"; ?>" class="btn btn-default">tracking<span class="glyphicon glyphicon-map-marker"></span></a>
            <a href="order-items.php?orid=<?php echo "{$row['order_id']}"; ?>" class="btn btn-success">View</a> <a href="my-orders.php?delete=<?php echo "{$row['order_id']}"; ?>" class="btn btn-danger">Remove</a>
        </div>

    </div>
<br>
<?php } ?>    
	
        
<br>
		<div class="row">
            <div class="col-md-offset-11 col-md-1 col-sm-offset-11 col-sm-1">
            <a href="http://www.greenmart.cf/" style="min-width: 100%;" class="btn btn-success pull-right">Back</a>
        
            </div>      
        </div>




	</div>

        <!--footer-->
    <?php require_once('inc/footer.php'); ?>
</body>
</html>