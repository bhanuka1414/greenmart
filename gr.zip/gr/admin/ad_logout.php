<?php require_once('../inc/sql_con.php'); ?>
<?php 

	session_start();
	date_default_timezone_set('Asia/Kolkata');

	$date_now1=date('d-m-Y  H:i:s');
	$sql="UPDATE ad_sub_ad SET last_logout='{$date_now1}' WHERE id='{$_SESSION["uida"]}'";
    $res=mysqli_query($con, $sql);
	$_SESSION=array();

	if(isset($_COOKIE[session_name()]))
	{
		setcookie(session_name(),'',time()-86400,'/');
	}
	session_destroy();
	header("Location:http://www.greenmart.cf/");

 ?>