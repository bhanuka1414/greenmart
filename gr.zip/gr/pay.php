<?php 
$product_name = $_GET["product_name"];//order no
$price = $_GET["product_price"];
$name = $_GET["name"];
$id = $_GET['uid'];
$email = $_GET["email"];
$lat = $_GET["lat"];
$lon = $_GET["lon"];
$phone="+94{$_GET["phone"]}";

include 'src/instamojo.php';

$api = new Instamojo\Instamojo('YOUR_KEY', 'SLT','https://test.instamojo.com/api/1.1/');


try {
    $response = $api->paymentRequestCreate(array(
        "purpose" => $product_name,
        "amount" => $price,
        "buyer_name" => $name,
        "phone" => $phone,
        "send_email" => true,
        "send_sms" => true,
        "email" => $email,
        'allow_repeated_payments' => false,
        "redirect_url" => "http://www.greenmart.cf/thankyou.php",
        "webhook" => "http://www.greenmart.cf/webhook.php?lat={$lat}&lon={$lon}&uid={$id}"
        ));
    //print_r($response);

    $pay_ulr = $response['longurl'];
    
    //Redirect($response['longurl'],302); //Go to Payment page

    header("Location: $pay_ulr");
    exit();

}
catch (Exception $e) {
    print('Error: ' . $e->getMessage());
}     
  ?>
