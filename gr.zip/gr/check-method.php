<?php session_start(); ?>
<?php require_once('inc/sql_con.php'); ?>
<?php 
    if (!isset($_SESSION["uid"])) {
        header('LOCATION:http://www.greenmart.cf/');
    }
 ?>
 <?php 
 	$sqlcus="SELECT f_name,email,phone FROM user WHERE id={$_SESSION["uid"]}";
 	$rescus=mysqli_query($con, $sqlcus);
 	$row1=mysqli_fetch_assoc($rescus);
 	$pn=$row1['phone'];
  ?>
<?php 
		switch ($_POST['rdo-pay']) {
			case 'c':
					if ($_POST['rdo-loc']=='cl') { //current location online
						?>
							
							
		<html>
			<body onload="getLocation()">

				<p id="demo"></p>

					<script>
						var x = document.getElementById("demo");

							function getLocation() {
    							if (navigator.geolocation) {
        							navigator.geolocation.getCurrentPosition(showPosition);
    							} else { 
        							x.innerHTML = "Geolocation is not supported by this browser.";
    							}
							}

							function showPosition(position) {
    							top.location.href="http://www.greenmart.cf/pay.php?product_price=<?php echo "{$_POST['ta']}"; ?>&name=<?php echo "{$row1['f_name']}"; ?>&phone=<?php echo "{$pn}"; ?>&lat="+position.coords.latitude+"&lon="+position.coords.longitude+"&email=<?php echo "{$row1['email']}"; ?>&product_name=GreenMart&uid=<?php echo "{$_SESSION['uid']}"; ?>";
							}

					</script>

			</body>
		</html>

<?php

					}
					else
					{
						//get home loc online
						$sql="SELECT loc_lat,loc_lon FROM user WHERE id={$_SESSION['uid']}";//get location fron db
					$res=mysqli_query($con, $sql);
					$row=mysqli_fetch_assoc($res);
					header("LOCATION:pay.php?product_price={$_POST['ta']}&lat={$row['loc_lat']}&lon={$row['loc_lon']}&name={$row1['f_name']}&phone={$pn}&email={$row1['email']}&product_name=GreenMart&uid={$_SESSION['uid']}");
					}
				break;
			case 'n':
					//same online
			if ($_POST['rdo-loc']=='cl') { //current location online
						?>
							
							
		<html>
			<body onload="getLocation()">

				<p id="demo"></p>

					<script>
						var x = document.getElementById("demo");

							function getLocation() {
    							if (navigator.geolocation) {
        							navigator.geolocation.getCurrentPosition(showPosition);
    							} else { 
        							x.innerHTML = "Geolocation is not supported by this browser.";
    							}
							}

							function showPosition(position) {
    							top.location.href="http://www.greenmart.cf/pay.php?product_price=<?php echo "{$_POST['ta']}"; ?>&name=<?php echo "{$row1['f_name']}"; ?>&phone=<?php echo "{$pn}"; ?>&lat="+position.coords.latitude+"&lon="+position.coords.longitude+"&email=<?php echo "{$row1['email']}"; ?>&product_name=GreenMart&uid=<?php echo "{$_SESSION['uid']}"; ?>";
							}

					</script>

			</body>
		</html>

<?php

					}
					else
					{
						//get home loc online
						$sql="SELECT loc_lat,loc_lon FROM user WHERE id={$_SESSION['uid']}";//get location fron db
					$res=mysqli_query($con, $sql);
					$row=mysqli_fetch_assoc($res);
					header("LOCATION:pay.php?product_price={$_POST['ta']}&lat={$row['loc_lat']}&lon={$row['loc_lon']}&name={$row1['f_name']}&phone={$pn}&email={$row1['email']}&product_name=GreenMart&uid={$_SESSION['uid']}");
					}

				break;
			case 'cd':
					if ($_POST['rdo-loc']=='cl') { //current location
						?>
							
							
		<html>
			<body onload="getLocation()">

				<p id="demo"></p>

					<script>
						var x = document.getElementById("demo");

							function getLocation() {
    							if (navigator.geolocation) {
        							navigator.geolocation.getCurrentPosition(showPosition);
    							} else { 
        							x.innerHTML = "Geolocation is not supported by this browser.";
    							}
							}

							function showPosition(position) {
    							xmlhttp = new XMLHttpRequest();
								xmlhttp.open("GET","transaction.php?opt=up&loc=<?php echo "{$_POST['rdo-loc']}"; ?>&lat="+position.coords.latitude+"&lon="+position.coords.longitude+"&ta=10",false);
        						xmlhttp.send(null);
        	
        						if (xmlhttp.responseText==1) {
        							top.location.href="http://www.greenmart.cf/my-orders.php";
        						}
							}
					</script>

			</body>
		</html>

<?php

					}
					else
					{
						header("LOCATION:transaction.php?ta={$_POST['ta']}&loc={$_POST['rdo-loc']}");//home location
					}
				break;	//end cash on delivery	
			
			default:
				echo "error";
				break;
		}
 ?>

 <?php mysqli_close($con); ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<h1>Location error!</h1>
</body>
</html>
			



			