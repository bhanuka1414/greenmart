<?php require_once('inc/sql_con.php'); ?>
<?php session_start(); ?>
<?php 
    if (!isset($_GET['id'])) {
        header('LOCATION:http://www.greenmart.cf/');
    }  
 ?>

 <?php 
    if (isset($_POST['sb1'])) {
        if ($_POST['qty'] <= 0) {
            echo "<script>alert('Check quantity!');</script>";
        }
        else
        {
            if (isset($_SESSION["uid"])) {
                $sql="INSERT INTO cart VALUES ({$_SESSION["uid"]},{$_POST['id1']},{$_POST['qty']},{$_POST['tp1']})";
                $re=mysqli_query($con, $sql);
                if ($re) {
                    header('Location:cart.php');
                }
                else
                {
                    echo "<script>alert('Error Try again!');</script>";
                }
            }
            else
            {
                    echo "<script>alert('Login error msg!');</script>"; //edi
            }
        }
    }



  ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Rammetto+One" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/main.css">
    <link rel="shortcut icon" href="img/Artdesigner-Urban-Stories-Cart.ico" />
    <script src="bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="bootstrap/js/main.js"></script>
	<title>Item</title>
</head>
<body>
	<?php require_once('inc/top_nav.php'); ?>
    <div class="container">
        

	
		<br>
        <?php 
    $sql="SELECT * FROM products WHERE id={$_GET['id']}";
    $res=mysqli_query($con, $sql);
    $rows=mysqli_fetch_assoc($res);

  ?>
            <div class="col-sm-6">
            <?php echo '<img style="min-height: 400px; max-height: 400px;" class="img-responsive" src="data:image/jpeg;base64,'.base64_encode( $rows['img'] ).'"/>'; ?>
        </div>

        <div class="col-sm-6" style="border-left:2px solid #34495E;">
            <h3><?php echo "{$rows['p_name']}"; ?></h3>
            <br>
            <p><?php echo "{$rows['p_dis']}"; ?>.</p>
            <br>
            <br>
            <p>Unit Price : RS <span id="up"><?php echo "{$rows['p_price']}"; ?></span></p>
            <br>
            <form action="" method="POST"> <!--pass data input hidden. bp remember it-->
                <input type="number" value="1" name="qty" id="qty" style="max-width: 100px;" required>
                <input type="hidden" name="tp1" id="tp1" value="<?php echo "{$rows['p_price']}"; ?>">
                <input type="hidden" name="id1" value="<?php echo "{$_GET['id']}"; ?>">
                <label>Available(<?php echo "{$rows['qty']}"; ?>)</label>
                <br><br>
                <p>Total Price : RS <span id="tp"><?php echo "{$rows['p_price']}"; ?></span></p>
                <a href="<?php echo "{$_SERVER['HTTP_REFERER'] }"; ?>" class="btn btn-danger">Back</a>
                 <button type="submit" class="btn btn-success" name="sb1">add cart</button>

            </form>
            <br><br>
           
        </div>      
        <br>


	</div>

        <!--footer-->
    <?php require_once('inc/footer.php'); ?>
    <script>
        $(document).ready(function(){
    $("#qty").on('change keyup paste', function(){
        // Getting the current value of textarea
        var total = $(this).val() * $('#up').text();
        
        // Setting the Div content
        $("#tp").text(total);
        $("#tp1").val(total);
    });
});
    </script>
</body>
</html>