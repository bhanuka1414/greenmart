<?php session_start(); ?>
<?php require_once('../inc/sql_con.php'); ?>
<?php 
	if (isset($_GET['opt']) && $_GET['opt']=="up") {
		$sql="UPDATE delivery SET loc_lat={$_GET['lat']}, loc_lon={$_GET['lon']} WHERE id='{$_SESSION["uidd"]}'";
		$res=mysqli_query($con, $sql);
		if ($res) {
			if ($_GET['lon']==NULL) {
				echo "location not updating....";
			}
			else
			{
				echo " <span class='glyphicon glyphicon-map-marker'></span> location updating....";
			}
			
		}
		else
		{
			
			echo "location not updating....";
			
		}
	}
	
 ?>


 
      