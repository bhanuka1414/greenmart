<?php require_once('inc/sql_con.php'); ?>
<?php session_start(); ?>
<?php 
    if (!isset($_SESSION["uid"])) {
        header('LOCATION:http://www.greenmart.cf/');
    }
 ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Rammetto+One" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/main.css">
    <link rel="shortcut icon" href="img/Artdesigner-Urban-Stories-Cart.ico" />
    <script src="bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="bootstrap/js/main.js"></script>
    
    <title>greenmart</title>

    <script>
        
           $(function(){ //show fieldset
                $('.select-div').click(function(){
                    $('#warn').hide();
                   var v=$(this).attr('id');
                    $('fieldset').addClass("hidden");
                    $('#'+v+'1').removeClass('hidden');
                });
                $('#warn').hide();
           });
                      
    </script>
    <script>
        function getLocation() {//set home location
                                if (navigator.geolocation) {
                                    navigator.geolocation.getCurrentPosition(showPosition);
                                } else { 
                                   alert('zzzzzzzzz');
                                }
                            }

                            function showPosition(position) {
                                xmlhttp = new XMLHttpRequest();
                                xmlhttp.open("GET","set_loc.php?opt=up&loc=tt&lat="+position.coords.latitude+"&lon="+position.coords.longitude+"&ta=10",false);
                                xmlhttp.send(null);
            
                                
                                    alert(xmlhttp.responseText);
                                
                            } 
    </script>
</head>
 <?php 
        if (isset($_POST['change_name'])) {//change name
            $pw=sha1($_POST['n_pw']);
            $sql="SELECT password FROM user WHERE id={$_SESSION['uid']} AND password='{$pw}'";
            $res=mysqli_query($con, $sql);
            if (mysqli_num_rows($res)==1) {
                $sql="UPDATE user SET f_name='{$_POST['fn']}',l_name='{$_POST['ln']}' WHERE id={$_SESSION['uid']}";
                $res=mysqli_query($con, $sql);
                if ($res) {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-success');
                        $('#warn').removeClass('alert-warning');

                        $('#warn').show();
                        $('#warning').text('successfully updated!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
                else
                {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Unsuccessful!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
            }
            else
            {
                echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Check your password!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
            }
        }
        if (isset($_POST['change_email'])) {//change email
            $pw=sha1($_POST['email_pw']);
            $sql="SELECT id FROM user WHERE id={$_SESSION['uid']} AND password='{$pw}'";
            $res=mysqli_query($con, $sql);
            if (mysqli_num_rows($res)==1) {
                $sql="UPDATE user SET email='{$_POST['email']}' WHERE id={$_SESSION['uid']}";
                $res=mysqli_query($con, $sql);
                if ($res) {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-success');
                        $('#warn').removeClass('alert-warning');

                        $('#warn').show();
                        $('#warning').text('successfully updated!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
                else
                {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Unsuccessful!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
            }
            else
            {
                echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Check your password!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
            }
        }
        if (isset($_POST['change_pw'])) {//change password
            if ($_POST['n_pw'] == $_POST['con_pw']) {
                $pw=sha1($_POST['c_pw']);
            $sql="SELECT id FROM user WHERE id={$_SESSION['uid']} AND password='{$pw}'";
            $res=mysqli_query($con, $sql);
            if (mysqli_num_rows($res)==1) {
                $pwn=sha1($_POST['n_pw']);
                $sql="UPDATE user SET password='{$pwn}' WHERE id={$_SESSION['uid']}";
                $res=mysqli_query($con, $sql);
                if ($res) {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-success');
                        $('#warn').removeClass('alert-warning');

                        $('#warn').show();
                        $('#warning').text('successfully updated!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
                else
                {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Unsuccessful!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
            }
            else
            {
                echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Check your password!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
            }
            }
            else//pass not match
            {
                echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Password not match!!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
            }
        }
        if (isset($_POST['change_us'])) {//change username
            $pw=sha1($_POST['us_pw']);
            $sql="SELECT id FROM user WHERE id={$_SESSION['uid']} AND password='{$pw}'";
            $res=mysqli_query($con, $sql);
            if (mysqli_num_rows($res)==1) {
                $sql="UPDATE user SET username='{$_POST['us']}' WHERE id={$_SESSION['uid']}";
                $res=mysqli_query($con, $sql);
                if ($res) {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-success');
                        $('#warn').removeClass('alert-warning');

                        $('#warn').show();
                        $('#warning').text('successfully updated!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
                else
                {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Unsuccessful!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
            }
            else
            {
                echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Check your password!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
            }
        }
        if (isset($_POST['change_add'])) {
            $pw=sha1($_POST['add_pw']);
            $sql="SELECT id FROM user WHERE id={$_SESSION['uid']} AND password='{$pw}'";
            $res=mysqli_query($con, $sql);
            if (mysqli_num_rows($res)==1) {
                $sql="UPDATE user SET address='{$_POST['add']}' WHERE id={$_SESSION['uid']}";
                $res=mysqli_query($con, $sql);
                if ($res) {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-success');
                        $('#warn').removeClass('alert-warning');

                        $('#warn').show();
                        $('#warning').text('successfully updated!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
                else
                {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Unsuccessful!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
            }
            else
            {
                echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Check your password!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
            }
        }
        if (isset($_POST['change_pn'])) {
            $pw=sha1($_POST['pn_pw']);
            $sql="SELECT id FROM user WHERE id={$_SESSION['uid']} AND password='{$pw}'";
            $res=mysqli_query($con, $sql);
            if (mysqli_num_rows($res)==1) {
                $sql="UPDATE user SET phone='{$_POST['pn']}' WHERE id={$_SESSION['uid']}";
                $res=mysqli_query($con, $sql);
                if ($res) {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-success');
                        $('#warn').removeClass('alert-warning');

                        $('#warn').show();
                        $('#warning').text('successfully updated!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
                else
                {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Unsuccessful!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
            }
            else
            {
                echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Check your password!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
            }
        }
  ?>
<body>
    <?php require_once('inc/top_nav.php'); ?>
    
    <h2 class="text-center">USER SETTINGS</h2>
    <hr>
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <div class="list-group">
                    <a href="#" class="list-group-item list-group-item-success" id="location" onclick="getLocation()">
                    Set Home Location <i class="fa fa-map-marker" aria-hidden="true"></i></a>
                    <a href="#name1" class="list-group-item select-div" id="name">Change Name</a>
                    <a href="#email1" class="list-group-item select-div" id="email">Change Email</a>
                    <a href="#address1" class="list-group-item select-div" id="address">Change Address</a>
                    <a href="#pn1" class="list-group-item select-div" id="pn">Change Phone Number</a>
                    <a href="#us1" class="list-group-item select-div" id="us">Change Username</a>
                    <a href="#pw1" class="list-group-item select-div" id="pw">Change Password</a>
                </div>
            </div>
           

            <fieldset id="name1" class="hidden col-sm-9" style="min-height: 500px;">

            <center><legend>Change Name:</legend></center>
                <div>           
                    <form style="top: 0px; bottom: 0px;" action="" method="POST">
                        <div class="form-group">
                            <label>First Name:</label>
                            <input type="text" class="form-control" name="fn" required>
                        </div>
                        <div class="form-group">
                            <label>Last Name:</label>
                            <input type="text" class="form-control" name="ln" required>
                        </div>
                        <div class="form-group">
                            <label>Password:</label>
                            <input type="password" class="form-control" name="n_pw" required>
                        </div>
                        <button type="submit" class="btn btn-default" name="change_name">Submit</button>
                    </form>
                </div>    
            </fieldset>

            
            <fieldset id="address1" class="hidden col-sm-9" style="min-height: 500px;">

            <center><legend>Change Address:</legend></center>
                <div>           
                    <form style="top: 0px; bottom: 0px;" action="" method="POST">
                        <div class="form-group">
                            <label>Address:</label>
                            <input type="text" class="form-control" name="add" required>
                        </div>
                        <div class="form-group">
                            <label>Password:</label>
                            <input type="password" class="form-control" name="add_pw" required>
                        </div>
                        <button type="submit" class="btn btn-default" name="change_add">Submit</button>
                    </form>
                </div>    
            </fieldset>

            
            <fieldset id="email1" class="hidden col-sm-9" style="min-height: 500px;">

            <center><legend>Change E-mail:</legend></center>
                <div>           
                    <form style="top: 0px; bottom: 0px;" action="" method="POST">
                        <div class="form-group">
                            <label>Email address:</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <div class="form-group">
                            <label>Password:</label>
                            <input type="password" class="form-control" name="email_pw" required>
                        </div>
                        <button type="submit" class="btn btn-default" name="change_email">Submit</button>
                    </form>
                </div>    
            </fieldset>

            <fieldset id="pn1" class="hidden col-sm-9" style="min-height: 500px;">

            <center><legend>Change Phane Number:</legend></center>
                <div>           
                    <form style="top: 0px; bottom: 0px;" action="" method="POST">
                        <div class="form-group">
                            <label>New Phane No:</label>
                            <div class="input-group">
                                <span class="input-group-addon">+94</span>
                            <input type="text" class="form-control" name="pn" required maxlength="9">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Password:</label>
                            <input type="password" class="form-control" name="pn_pw" required>
                        </div>
                        <button type="submit" class="btn btn-default" name="change_pn">Submit</button>
                    </form>
                </div>    
            </fieldset>

            <fieldset id="us1" class="hidden col-sm-9" style="min-height: 500px;">

            <center><legend>Change Username:</legend></center>
                <div>           
                    <form style="top: 0px; bottom: 0px;" action="" method="POST">
                        <div class="form-group">
                            <label>New Username:</label>
                            <input type="text" class="form-control" name="us" required>
                        </div>
                        <div class="form-group">
                            <label>Password:</label>
                            <input type="password" class="form-control" name="us_pw" required>
                        </div>
                        <button type="submit" class="btn btn-default" name="change_us">Submit</button>
                    </form>
                </div>    
            </fieldset>

            <fieldset id="pw1" class="hidden col-sm-9" style="min-height: 500px;">

            <center><legend>Change Password:</legend></center>
                <div>           
                    <form style="top: 0px; bottom: 0px;" action="" method="POST">
                        <div class="form-group">
                            <label>Current Password:</label>
                            <input type="password" class="form-control" name="c_pw" required>
                        </div>
                        <div class="form-group">
                            <label>New Password:</label>
                            <input type="password" class="form-control" name="n_pw" required>
                        </div>
                        <div class="form-group">
                            <label>Confirm Password:</label>
                            <input type="password" class="form-control" name="con_pw" required>
                        </div>
                        <button type="submit" class="btn btn-default" name="change_pw">Submit</button>
                    </form>
                </div>    
            </fieldset>
            
        </div>
            <div class="alert alert-warning col-sm-offset-3" id="warn">
                <strong>Warning!</strong> <span id="warning"></span>
            </div>
    </div>
    <!--container end-->
<!--footer-->
    <?php require_once('inc/footer.php'); ?>
</body>


</html>