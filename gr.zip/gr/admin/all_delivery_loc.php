<?php session_start(); ?>
<?php require_once('../inc/sql_con.php'); ?>
<?php 
    if (!isset($_SESSION["admin"])) {
        header('LOCATION:http://www.greenmart.cf/admin/');
    }
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/main.css">
    <link rel="shortcut icon" href="../img/Artdesigner-Urban-Stories-Cart.ico" />
    <script src="../bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/main.js"></script>
	<title>Admin</title>
	
    <style>
@media screen and (max-width: 750px)
{
    
    body { padding-top: 0px; }
   
}
body { padding-top: 0px; height: 100%;}
#map {
        height: 500px;
      }
#wdg
      {
        position: absolute;
        z-index: 2;
       
        opacity: 0.8;
        
        bottom: 10px;
        
      }
      #wdg:hover
      {
        opacity: 1;

      }
    </style>
</head>
<body>
<?php require_once('../inc/admin_tmp.php'); ?>
<br><br>

<div class="container">
<center><h3>DELIVERY SERVICE</h3></center>
	<div id="map"></div>
    <script>
      var marker;

      function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 13,
          center: {lat: 7.29972849, lng: 80.6354624}
        });
        <?php 
            $sql="SELECT l_name,loc_lat,loc_lon FROM delivery";
            $res=mysqli_query($con, $sql);
            while ($row=mysqli_fetch_assoc($res)) { ?>
        marker = new google.maps.Marker({
          map: map,
          draggable: true,
          icon: '../img/truck_delivery_logistics_transportation_shipping_deliver_shipment_v3-128.png',
          label: '<?php echo "{$row['l_name']}"; ?>',
          position: {lat: <?php echo "{$row['loc_lat']}"; ?>, lng: <?php echo "{$row['loc_lon']}"; ?>}
        });
        <?php } ?>

      }

    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY&callback=initMap">
    </script>
    <a href="all_delivery_loc.php" id="wdg" class="btn btn-danger">current possition</a>
</div>
</body>
</html>

