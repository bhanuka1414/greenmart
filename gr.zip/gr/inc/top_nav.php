<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
?>
<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
        <button class="navbar-toggle" data-toggle="collapse" data-target=".navHeaderCollapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        <div class="navbar-header">
            <a href="http://www.greenmart.cf/" class="navbar-brand" style="font-family: 'Rammetto One', cursive;"><img src="http://www.greenmart.cf/img/Logo 2 low res.png" alt="" class="img-responsive" style="max-width: 100px;"></a>
        </div>
        
        <form class="form-search navbar-form navbar-left" action="http://www.greenmart.cf/search.php" method="POST">
                <div class="input-group navbar-right searchbox">
                    <input type="search" class="form-control" placeholder="search..." name="search">
                    <span class="input-group-btn">
                        <button type="submit" name="sb" class="btn btn-success">Search</button>
                    </span>
                </div>
            </form>        
    
            <div class="collapse navbar-collapse navHeaderCollapse">
                <ul class="nav navbar-nav navbar-right">
                <?php 
                    if (isset($_SESSION["uid"])) {
                        $sql="SELECT f_name FROM user WHERE id={$_SESSION["uid"]}";
                        $res=mysqli_query($con, $sql);
                        $row=mysqli_fetch_assoc($res);

                        //count cart items
                        $sql11="SELECT COUNT(*) FROM cart WHERE cid={$_SESSION["uid"]}";
                        $res11=mysqli_query($con, $sql11);
                        $row11=mysqli_fetch_array($res11);
                        echo '
                    <li><a href="http://www.greenmart.cf/cart.php"><span class="glyphicon glyphicon-shopping-cart"></span>Cart
                    <span style="color:red;">'.$row11[0].'</span></a></li>
                    <!--not login show reg & login else show account & cart-->
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span> '.$row["f_name"].'<span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="http://www.greenmart.cf/my-orders.php">MYorders</a></li>
                            <li><a href="http://www.greenmart.cf/settings.php">Settings</a></li>
                            <li><a href="http://www.greenmart.cf/inc/logout.php"><span class="glyphicon glyphicon-log-out"></span>Sign-out</a></li>
                        </ul>
                    </li>';
                    }
                    else
                    {
                        echo '<li><a href="http://www.greenmart.cf/login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                        <li><a href="http://www.greenmart.cf/register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>';
                    }
                 ?>
                    
                </ul>

            </div>
            
        </div>
        <?php require_once('desktop_cat.php'); ?>
    </nav>
    
    <!--end navbar top -->
