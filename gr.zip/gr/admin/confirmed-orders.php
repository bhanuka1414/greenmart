<?php session_start(); ?>
<?php require_once('../inc/sql_con.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/main.css">
    <link rel="shortcut icon" href="../img/Artdesigner-Urban-Stories-Cart.ico" />
    <script src="../bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/main.js"></script>
	<title>Admin</title>
	<style>
@media screen and (max-width: 750px)
{
    
    body { padding-top: 0px; }
   
}
body { padding-top: 0px; }

    </style>
</head>
<body>
<?php require_once('../inc/admin_tmp.php'); ?>
<br><br>
<div class="container">
<center><h3>Confirmed Orders</h3></center>
<form class="form-search" method="get" id="s" action="">
    <div class="input-append">
        <input  style="width: 230px;" type="text" class="input-medium search-query" name="s" placeholder="Search" value="">
        <button type="submit" class="add-on" name="seaech"><i class="glyphicon glyphicon-search"></i></button>
    </div>
</form>
	<div class="row text-center hidden-xs hidden-sm" style="border-bottom: 1px solid black;"><hr>
		<div class="col-md-2">
            <h5>Order No</h5>
        </div>
        <div class="col-md-2">
            <h5>Date - Time</h5>
        </div>
        <div class="col-md-1">
            <h5>Total Amount</h5>
        </div>
        <div class="col-md-2">
            <h5>FEEDBACK</h5>
        </div>
        <div class="col-md-1">
            <h5>Phone NO</h5>
        </div>
        <div class="col-md-2">
            <h5>Name</h5>
        </div>
        <div class="col-md-2">
            <h5>Action</h5>
        </div>
	</div>
    <br>
<?php
if (isset($_GET['seaech'])) {
     $sql="SELECT * FROM orders WHERE confirm=1 AND order_id LIKE '%{$_GET['s']}%' ORDER BY order_id DESC";
 }
 else
 {
    $sql="SELECT * FROM orders WHERE confirm=1 ORDER BY order_id DESC";
 } 
    
    $res=mysqli_query($con, $sql);
    while ($row=mysqli_fetch_assoc($res)) {
        $sql1="SELECT * FROM user WHERE id={$row['cid']}";
        $res1=mysqli_query($con, $sql1);
        $row1=mysqli_fetch_assoc($res1)
 ?>
 <?php $date="{$row["date1"]} / {$row["month"]} / {$row["year"]}   {$row["time1"]}"; ?>
    <div class="row text-center" style="border: 1px solid #D5D8DC; border-radius: 7px;">
        <div class="col-md-2">
            <h6 class="text-left hidden-md hidden-lg">ORDER NO:</h6><p><?php echo "{$row['order_id']}"; ?></p>
        </div>
        <div class="col-md-2">
            <h6 class="text-left hidden-md hidden-lg">DATE:</h6><p><?php echo "{$date}"; ?></p>
        </div>
        <div class="col-md-1">
            <h6 class="text-left hidden-md hidden-lg">TOTAL AMOUNT:</h6><p>RS <?php echo "{$row['total_am']}"; ?></p>
        </div>
        <div class="col-md-3">
            <h6 class="text-left hidden-md hidden-lg">FEEDBACK:</h6><p style="background-color: #EBEDEF;"><?php echo "{$row['feedback']}"; ?></p>
        </div>
        <div class="col-md-1">
            <h6 class="text-left hidden-md hidden-lg">PHONE NO:</h6><p><?php echo "{$row1['phone']}"; ?></p>
        </div>
        <div class="col-md-2">
            <h6 class="text-left hidden-md hidden-lg">NAME:</h6><p><?php echo "{$row1['l_name']}"; ?></p>
        </div>
        <div class="col-md-1">
            <a href="http://www.greenmart.cf/admin/order-item-confirm.php?co=1&orid=<?php echo "{$row['order_id']}"; ?>&opt=1" class="btn btn-primary">View Order</a > 
            
        </div>
    </div>
    <br>
<?php } ?>
</div>
</body>
</html>

