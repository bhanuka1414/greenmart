<?php session_start(); ?>
<?php require_once('../inc/sql_con.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/main.css">
    <link rel="shortcut icon" href="../img/Artdesigner-Urban-Stories-Cart.ico" />
    <script src="../bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/main.js"></script>
	<title>Admin</title>
	<script>
        
           $(function(){ //show fieldset
                $('.select-div').click(function(){
                    $('#warn').hide();
                   var v=$(this).attr('id');
                    $('fieldset').addClass("hidden");
                    $('#'+v+'1').removeClass('hidden');
                });
                $('#warn').hide();
           });
                      
    </script>
    <style>
@media screen and (max-width: 750px)
{
    
    body { padding-top: 0px; }
   
}
body { padding-top: 0px; }

    </style>
</head>
<body>
<?php require_once('../inc/admin_tmp.php'); ?>
<?php 
                if (isset($_POST['img_ok'])) {
            if (isset($_FILES['p_img']) && $_FILES['p_img']['size'] > 0) {

                if ($_FILES['p_img']['size']<200000){
// Temporary file name stored on the server

                    $tmpName = $_FILES['p_img']['tmp_name'];


// Read the file

                        $fp = fopen($tmpName, 'r');

                        $data = fread($fp, filesize($tmpName));

                        $data = addslashes($data);

                $sqlimg="UPDATE ad_sub_ad SET  img='{$data}' WHERE id='{$_SESSION['uida']}'";
                $resimg=mysqli_query($con, $sqlimg);
                unset($_POST);
                }
            }
        }
 ?>
<?php 
        $sql1="SELECT * FROM ad_sub_ad WHERE id='{$_SESSION["uida"]}'";
        $res1=mysqli_query($con, $sql1);
        $row1=mysqli_fetch_array($res1);
 ?>
 <?php 
    if (isset($_POST['change_us'])) {//change username
            $pw=sha1($_POST['us_pw']);
            $sql="SELECT id FROM ad_sub_ad WHERE id='{$_SESSION['uida']}' AND password='{$pw}'";
            $res=mysqli_query($con, $sql);
            if (mysqli_num_rows($res)==1) {
                $sql="UPDATE ad_sub_ad SET username='{$_POST['us']}' WHERE id='{$_SESSION['uida']}'";
                $res=mysqli_query($con, $sql);
                if ($res) {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-success');
                        $('#warn').removeClass('alert-warning');

                        $('#warn').show();
                        $('#warning').text('successfully updated!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
                else
                {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Unsuccessful!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
            }
            else
            {
                echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Check your password!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
            }
        }
        if (isset($_POST['change_pw'])) {//change password
            if ($_POST['n_pw'] == $_POST['con_pw']) {
                $pw=sha1($_POST['c_pw']);
            $sql="SELECT id FROM ad_sub_ad WHERE id='{$_SESSION['uida']}' AND password='{$pw}'";
            $res=mysqli_query($con, $sql);
            if (mysqli_num_rows($res)==1) {
                $pwn=sha1($_POST['n_pw']);
                $sql="UPDATE ad_sub_ad SET password='{$pwn}' WHERE id='{$_SESSION['uida']}'";
                $res=mysqli_query($con, $sql);
                if ($res) {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-success');
                        $('#warn').removeClass('alert-warning');

                        $('#warn').show();
                        $('#warning').text('successfully updated!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
                else
                {
                    echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Unsuccessful!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
                }
            }
            else
            {
                echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Check your password!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
            }
            }
            else//pass not match
            {
                echo "<script>$(function(){
                        $('#warn').addClass('alert-warning');
                        $('#warn').removeClass('alert-success');
                        $('#warn').show();
                        $('#warning').text('Password not match!!');
                        $('html, body').animate({
                            'scrollTop' : $('#warning').position().top
                        });
                        });</script>";
            }
        }
  ?>
<br><br>
<div class="container">
<center><h3>PROFILE & SETTINGS</h3></center>
<br>
<div class="row">
    <div class="col-md-6"><center>
                    <?php echo '<img class="img-circle img-responsive" style="max-height: 450px; width: auto;" src="data:image/jpeg;base64,'.base64_encode( $row1['img'] ).'"/>'; ?></center>
                    <div class="form-group">
                        <form action="" method="post" enctype="multipart/form-data">
                            <label class="btn btn-success btn-file">
                                Browse <input type="file" name="p_img" style="display: none;">
                            </label>
                            <button type="submit" class="btn btn-primary" name="img_ok">OK</button>
                        </form>
                            
                    </div>
    </div>
    <div class="col-md-5 col-md-offset-1">
        <div class="row">
            <div class="col-md-12">
                <strong>ID No:</strong><p style="padding-left: 100px;"><?php echo "{$row1['id']}"; ?></p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <strong>FIRST NAME:</strong><p style="padding-left: 100px;"><?php echo "{$row1['f_name']}"; ?></p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <strong>LAST NAME:</strong><p style="padding-left: 100px;"><?php echo "{$row1['l_name']}"; ?></p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <strong>ADDRESS:</strong><p style="padding-left: 100px;"><?php echo "{$row1['address']}"; ?></p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <strong>E-mail:</strong><p style="padding-left: 100px;"><?php echo "{$row1['email']}"; ?></p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <strong>PHONE 1:</strong><p style="padding-left: 100px;"><?php echo "{$row1['phone']}"; ?></p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <strong>PHONE 2:</strong><p style="padding-left: 100px;"><?php echo "{$row1['phone2']}"; ?></p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <strong>TYPE:</strong><p style="padding-left: 100px;"><?php 
                if ($row1['type']==1) {
                    $type="ADMIN";
                }else{
                    $type="SUB ADMIN";
                }
                echo "{$type}";
                 ?></p>
            </div>
        </div>
    </div>
</div>
<hr><br>
<h3>SETTINGS</h3>
<br>
    <div class="row">

            <div class="col-sm-3">
                <div class="list-group">
                    <a href="#us1" class="list-group-item select-div" id="us">Change Username</a>
                    <a href="#pw1" class="list-group-item select-div" id="pw">Change Password</a>
                </div>
            </div>

            <fieldset id="us1" class="hidden col-sm-9" style="min-height: 500px;">

            <center><legend>Change Username:</legend></center>
                <div>           
                    <form style="top: 0px; bottom: 0px;" action="" method="POST">
                        <div class="form-group">
                            <label>New Username:</label>
                            <input type="text" class="form-control" name="us" required>
                        </div>
                        <div class="form-group">
                            <label>Password:</label>
                            <input type="password" class="form-control" name="us_pw" required>
                        </div>
                        <button type="submit" class="btn btn-default" name="change_us">Submit</button>
                    </form>
                </div>    
            </fieldset>

            <fieldset id="pw1" class="hidden col-sm-9" style="min-height: 500px;">

            <center><legend>Change Password:</legend></center>
                <div>           
                    <form style="top: 0px; bottom: 0px;" action="" method="POST">
                        <div class="form-group">
                            <label>Current Password:</label>
                            <input type="password" class="form-control" name="c_pw" required>
                        </div>
                        <div class="form-group">
                            <label>New Password:</label>
                            <input type="password" class="form-control" name="n_pw" required>
                        </div>
                        <div class="form-group">
                            <label>Confirm Password:</label>
                            <input type="password" class="form-control" name="con_pw" required>
                        </div>
                        <button type="submit" class="btn btn-default" name="change_pw">Submit</button>
                    </form>
                </div>    
            </fieldset>
        
    </div>
            <div class="alert alert-warning col-sm-offset-3" id="warn">
                <strong>Warning!</strong> <span id="warning"></span>
            </div>
</div>
</body>
</html>

