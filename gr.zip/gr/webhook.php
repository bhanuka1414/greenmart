<?php require_once('inc/sql_con.php'); ?>
<?php session_start(); ?>
<?php

$data = $_POST;
$mac_provided = $data['mac'];  // Get the MAC from the POST data
unset($data['mac']);  // Remove the MAC key from the data.

$ver = explode('.', phpversion());
$major = (int) $ver[0];
$minor = (int) $ver[1];

if($major >= 5 and $minor >= 4){
     ksort($data, SORT_STRING | SORT_FLAG_CASE);
}
else{
     uksort($data, 'strcasecmp');
}

// You can get the 'salt' from Instamojo's developers page(make sure to log in first): https://www.instamojo.com/developers
// Pass the 'salt' without the <>.
$mac_calculated = hash_hmac("sha1", implode("|", $data), "YOUR_slt");

if($mac_provided == $mac_calculated){
    echo "MAC is fine";
    // Do something here
    if($data['status'] == "Credit"){
       // Payment was successful, mark it as completed in your database  
                date_default_timezone_set('Asia/Kolkata');
		
		
				$year=date('Y');
				$month=date('m');
				$date=date('d');
				$time=date('H:i');
				$oid1=date('dmYHis');
				$orderid=$_GET['uid'].$oid1;

               // $to = 'mail@domain.com';
               /* $subject = 'Website Payment Request ' .$data['buyer_name'].'';
                $message = "<h1>Payment Details</h1>";
                $message .= "<hr>";
                $message .= '<p><b>ID:</b> '.$data['payment_id'].'</p>';
                $message .= '<p><b>Amount:</b> '.$data['amount'].'</p>';
                $message .= "<hr>";
                $message .= '<p><b>Name:</b> '.$data['buyer_name'].'</p>';
                $message .= '<p><b>Email:</b> '.$data['buyer'].'</p>';
                $message .= '<p><b>Phone:</b> '.$data['buyer_phone'].'</p>';*/
                
                
                $sql="INSERT INTO orders(order_id,cid,year,month,date1,time1,total_am,confirm,remove,feedback,tmp_lat,tmp_lon,payment_type)VALUES({$orderid},
					{$_GET['uid']},{$year},{$month},{$date},'{$time}',{$data['amount']},0,0,'nof',{$_GET['lat']},{$_GET['lon']},'{$data['payment_id']}')";
				$res= mysqli_query ($con, $sql); //end 

				$sql2="SELECT * FROM cart WHERE cid={$_GET['uid']}";
				$res2=mysqli_query($con, $sql2);
					while ($row=mysqli_fetch_assoc($res2))//while end of cart
					{
			
						$sql3="INSERT INTO order_item(item_id,order_id,qty,price)VALUES({$row['pid']},{$orderid},{$row['qty']},{$row['tp']})";  //insert to order items
						$res3=mysqli_query($con, $sql3);

						$sql5="UPDATE products SET qty=(qty-{$row['qty']}),sold=(sold+{$row['qty']}) WHERE id={$row['pid']}";// reduce stock
						$results4 = mysqli_query($con, $sql5);
			
			
					}//end while
			$sql="DELETE FROM cart WHERE cid={$_GET['uid']}";
			$res4=mysqli_query($con, $sql);
			
				

                $message .= "<hr>";

              
               // $headers .= "MIME-Version: 1.0\r\n";
                //$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
                // send email
                //mail($to, $subject, $message, $headers);




    }
    else{
       // Payment was unsuccessful, mark it as failed in your database
    }
}
else{
    echo "Invalid MAC passed";
}
?>
