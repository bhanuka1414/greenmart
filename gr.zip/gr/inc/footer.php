<div class="navbar navbar-inverse" style="min-height: 300px; margin-top: 20px; margin-bottom: 0px; border-radius: 0;">
    	<div class="container">
    		<div class="row" style="margin-top: 30px; text-align: center; border: 3px solid #C0392B;;">
    		<div class="col-xs-3"><a href="#"><i class="fa fa-rss" aria-hidden="true" style="font-size: 40pt;"></i></a></div>
    		<div class="col-xs-3"><a href="#"><i class="fa fa-facebook-official" aria-hidden="true" style="font-size: 40pt;"></i></a></div>
    		<div class="col-xs-3"><a href="#"><i class="fa fa-google-plus-official" aria-hidden="true" style="font-size: 40pt;"></i></a></div>
    		<div class="col-xs-3"><a href="#"><i class="fa fa-twitter" aria-hidden="true" style="font-size: 40pt;"></i></a></div>
    	</div>

    	<div class="row" style="margin-top: 40px;">
    		<div class="col-sm-12">
    			<center><a href="#mn" class="btn" data-toggle="modal" style="border:2px solid #AEB6BF;">Contact us</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="#about" class="btn" data-toggle="modal" style="border:2px solid #AEB6BF;">About us</a></center>
    		</div>
    	</div>

    	<div class="row" style="margin-top: 30px; text-align: center;">
    		<div class="col-md-12 navbar-text">© Copyright 2017 Green-mart. All Rights Reserved. <br> 
Powered by <a href="#">G-Code</a>.</div>
    	</div>
    	</div>
    </div>
    <a href="#" class="scrollToTop btn btn-danger"><i class="fa fa-chevron-up" aria-hidden="true"></i></a>

    
    <div class="modal fade" id="mn" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Didn’t receive an item? Or love to leave a feedback?</h3>
                </div>
                <div class="modal-body">
                    <table border="0">
                        <tr>
                            <td>Hotline: </td>
                            <td> 077 5752489</td>
                        </tr>
                        <tr>
                            <td>Tel: </td>
                            <td> 011 2547182</td>
                        </tr>
                        <tr>
                            <td>E-mail us: </td>
                            <td> greenmart@gmail.com </td>
                        </tr>
                    </table>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-success" data-dismiss="modal">ok</a>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="about" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>About us</h3>
                </div>
                <div class="modal-body">
                    <table border="0">
                        <tr>
                            <td>Hotline: </td>
                            <td> 077 5752489</td>
                        </tr>
                        <tr>
                            <td>Tel: </td>
                            <td> 011 2547182</td>
                        </tr>
                        <tr>
                            <td>E-mail us: </td>
                            <td> greenmart@gmail.com </td>
                        </tr>
                    </table>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-success" data-dismiss="modal">ok</a>
                </div>
            </div>
        </div>
    </div>

