<?php require_once('inc/sql_con.php'); ?>
<?php 
      $sqlloc="SELECT * FROM delivery WHERE order_id={$_GET['orid']}";
      $resloc=mysqli_query($con, $sqlloc);
      if (mysqli_num_rows($resloc)==1) {
        $rowloc=mysqli_fetch_assoc($resloc);
      }
      else
      {
        echo "<script>alert('Order not Confirmed!')</script>";
        header('LOCATION:http://www.greenmart.cf/my-orders.php');
      }
      
 ?>
<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Rammetto+One" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/main.css">
    <link rel="shortcut icon" href="img/Artdesigner-Urban-Stories-Cart.ico" />
    <script src="bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="bootstrap/js/main.js"></script>
<head>
	<meta charset="UTF-8">
	<title>Marker Clustering</title>
	<!-- <meta http-equiv="refresh" content="10; url=up_de_loc.php"> -->
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 500px;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #wdg
      {
        position: absolute;
        z-index: 1000;
        bottom: 10px;
        opacity: 0.8;
        position: fixed;
      }
      #wdg:hover
      {
        opacity: 1;

      }
    </style>
</head>
<body>
 <?php require_once('inc/top_nav.php'); ?>
 <br>

<div class="container">
  <div class="row">
    <div id="map" class="col-xs-12"></div>
  </div>
</div>
    <script>
      function mymap() {
        var deliverym = {lat: <?php echo "{$rowloc['loc_lat']}"; ?>, lng: <?php echo "{$rowloc['loc_lon']}"; ?>};
        var customerm = {lat: <?php echo "{$rowloc['cus_lat']}"; ?>, lng: <?php echo "{$rowloc['cus_lon']}"; ?>};
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 8,
          center: customerm,
          draggable: true,
          mapTypeControl: true,
          mapTypeControlOptions: {
              style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
              position: google.maps.ControlPosition.TOP_CENTER
          },
          zoomControl: true,
          zoomControlOptions: {
              position: google.maps.ControlPosition.LEFT_CENTER
          },
          scaleControl: true,
          streetViewControl: true,
          streetViewControlOptions: {
              position: google.maps.ControlPosition.LEFT_TOP
          },
          fullscreenControl: true
        });
         var directionsDisplay = new google.maps.DirectionsRenderer({
          map: map,
          suppressMarkers: true//hidden direction markers
        });
         var request = {
          destination: deliverym,
          origin: customerm,
          travelMode: 'DRIVING'
        };
         map.setOptions({ minZoom: 1, maxZoom: 16 });
        var marker = new google.maps.Marker({ // deliery loc
          position: deliverym,
          map: map,
          icon: 'img/truck_delivery_logistics_transportation_shipping_deliver_shipment_v3-128.png'
        });

        var marker = new google.maps.Marker({ //customer loc
          position: customerm,
          map: map,
          icon: 'img/34343.png'
        });

        var directionsService = new google.maps.DirectionsService();
        directionsService.route(request, function(response, status) {
          if (status == 'OK') {
            // Display the route on the map.
            directionsDisplay.setDirections(response);
          }
        });
      }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY&callback=mymap"
        async defer></script>
<a href="tracking.php?orid=<?php echo "{$_GET['orid']}"; ?>" id="wdg" class="btn btn-danger">current possition</a>
        <!--footer-->
<?php require_once('inc/footer.php'); ?>
  </body>
</html>