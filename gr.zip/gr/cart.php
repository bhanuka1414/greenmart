<?php session_start(); ?>
<?php 
    if (!isset($_SESSION["uid"])) {
        header('LOCATION:http://www.greenmart.cf/');
    }
 ?>
<?php require_once('inc/sql_con.php'); ?>
<?php 
    if (isset($_GET['delete'])) {
        $sql="DELETE FROM cart WHERE pid={$_GET['delete']}"; //delete from cart
        $res=mysqli_query($con, $sql);
    }
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Rammetto+One" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="bootstrap/css/main.css">
    <link rel="shortcut icon" href="img/Artdesigner-Urban-Stories-Cart.ico" />
    <script src="bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="bootstrap/js/main.js"></script>
	<title>Item</title>
</head>
<body>
	<?php require_once('inc/top_nav.php'); ?>
    <div class="container">
        

	
		<div class="table-responsive">
	<table class="table table-striped" style="text-align: center;">
    <thead>
      <tr>
        <th class="text-center">ITEM</th>
        <th class="text-center">QTY</th>
        <th class="text-center">PRICE</th>
        <th class="text-center">ACTION</th>
      </tr>
    </thead>
    <tbody>
    <?php
        $amount=0; 
            $sql="SELECT * FROM cart WHERE cid={$_SESSION["uid"]}";
            $res=mysqli_query($con, $sql);
            while ($row1=mysqli_fetch_assoc($res)) {
                $sql2="SELECT * FROM products WHERE id={$row1['pid']}";
                $res2=mysqli_query($con, $sql2);
                $row2=mysqli_fetch_assoc($res2);
     ?>
      <tr>
        <td style="max-width: 150px;">
        <span><?php echo '<img class="img-responsive hidden-xs" style="max-width: 100px; max-height:100px; float: left;" src="data:image/jpeg;base64,'.base64_encode( $row2['img'] ).'"/>'; ?></span>
        <span class="hidden-xs" style="max-width: 100%; display: block; overflow-y: scroll; max-height: 100px;">
        <?php echo "{$row2['p_dis']}"; ?></span>
        <p class="hidden-lg hidden-md hidden-sm"><?php echo "{$row2['p_name']}"; ?></p>
        </td>
        <td><?php echo "{$row1['qty']}"; ?></td>
        <td><?php echo "{$row1['qty']}"; ?> x <?php echo "{$row2['p_price']}"; ?> <span class="glyphicon glyphicon-triangle-right"></span> RS <?php echo "{$row1['tp']}"; ?>.</td>
        <td><a href="cart.php?delete=<?php echo "{$row1['pid']}"; ?>" class="btn btn-danger">Remove</a></td>
      </tr>
      <?php 

            $amount+=$row1['tp']; //cal total amo
      } ?>
    </tbody>
  </table>
  <?php 
            //tmp dilivery cost. need algorith for lacation based cost
            $d_cost=300;
            $total_amo=$d_cost+$amount;
   ?>
		</div>
        <div class="col-md-offset-9 col-md-3 col-sm-offset-8 col-sm-4 table-responsive">
            <table class="table table-hover">
                <tr>
                    <td>Amount</td>
                    <td>RS <?php echo "{$amount}"; ?></td>
                </tr>
                <tr>
                    <td>Dilivery Cost<a href="#" title="Dilivery details"><i class="fa fa-info-circle" aria-hidden="true"></i></a></td>
                    <td>RS <?php echo "{$d_cost}"; ?></td>
                </tr>
                <tr>
                    <td>Total Amount</td>
                    <td>RS <?php echo "{$total_amo}"; ?></td>
                </tr>
            </table>
        </div>

		<div class="col-md-offset-9 col-md-3 col-sm-offset-8 col-sm-4">
        <a href="http://www.greenmart.cf/" class="btn btn-success">Continue shopping</a>
        <a href="#payment" data-toggle="modal" class="btn btn-success pull-right">order</a>
        
        </div>

	</div><!--container end-->

    <div class="modal fade" id="payment" role="dialog"><!--model-->
        <div class="modal-dialog">
            <div class="modal-content">
            <form action="check-method.php" method="POST">
                <div class="modal-header">
                    <center><h3><u>Select Payment Method & delivery location</u></h3></center>
                </div>
                <div class="modal-body">
                
                <h4>Select Payment Method</h4>
                    <div class="radio-inline">
                        <label><input type="radio" name="rdo-pay" value="c" required>
                        <img style="max-height: 100px; max-width: 100px;" src="img/Credit Card-256x256.png" alt=""></label>
                    </div>
                    <div class="radio-inline">
                        <label><input type="radio" name="rdo-pay" value="n">
                        <img style="max-height: 100px; max-width: 100px;" src="img/netbanking.png" alt=""></label>
                    </div>
                    <div class="radio-inline">
                        <label><input type="radio" name="rdo-pay" value="cd">
                        <img style="max-height: 100px; max-width: 100px;" src="img/CASH_ON_DELIVERY.png" alt=""></label>
                    </div>
                    <br>
                    <h4>Select delivery location</h4>
                    <div class="radio-inline">
                        <label><input type="radio" name="rdo-loc" value="h" required>Home Location
                        <img style="max-height: 100px; max-width: 100px;" src="img/home-location.png" alt=""></label>
                    </div>
                    <div class="radio-inline">
                        <label><input type="radio" name="rdo-loc" value="cl">Current Location
                        <img style="max-height: 100px; max-width: 100px;" src="img/home-location (copy).png" alt=""></label>
                    </div>
                        <input type="hidden" name="ta" value="<?php echo "{$total_amo}"; ?>">
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-danger" data-dismiss="modal">Cancel</a>
                    <button class="btn btn-success" type="submit">Order</button>
                    
                </div>
            </form>
            </div>
        </div>
    </div>

        <!--footer-->
    <?php require_once('inc/footer.php'); ?>
</body>
</html>