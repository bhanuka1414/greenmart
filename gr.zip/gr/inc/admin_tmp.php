<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
?>
<?php 
    if (!isset($_SESSION["uida"])) {
      header('LOCATION:http://www.greenmart.cf/login.php');
    }
    else
    {
      $sql1="SELECT l_name,img FROM ad_sub_ad WHERE id='{$_SESSION["uida"]}'";
      $res1=mysqli_query($con, $sql1);
      $row1=mysqli_fetch_array($res1);
    }
 ?>
<?php 
    $sql="SELECT COUNT(*) FROM orders WHERE confirm=0";
    $res=mysqli_query($con, $sql);
    $row=mysqli_fetch_array($res);

 ?>
<div id="mySidenav" class="sidenav navbar navbar-inverse" style="z-index: 1000; opacity: 0.9;">
  
  <div class="list-group" id="men">
  <div class="dropdown">
    <a href="#" class="list-group-item ropdown-toggle admenu" style="color: #D6DBDF; border: 0px solid black;" data-toggle="dropdown" >Orders<span class="caret" style="float: right;"></span><span class="badge"><?php echo "{$row[0]}"; ?></span></a>
    <ul class="dropdown-menu" style="width: 100%;">
      <li class="text-right"><a href="http://www.greenmart.cf/admin/">New Orders</a></li>
      <li class="text-right"><a href="http://www.greenmart.cf/admin/confirmed-orders.php">Comfirmed Orders</a></li>
    </ul>
  </div>
  <div class="dropdown">
    <a href="#" class="list-group-item ropdown-toggle admenu" style="color: #D6DBDF; border: 0px solid black;" data-toggle="dropdown" >Products<span class="caret" style="float: right;"></span></a>
    <ul class="dropdown-menu" style="width: 100%;">
      <li class="text-right"><a href="http://www.greenmart.cf/admin/add_products.php">Add New Product</a></li>
      <li class="text-right"><a href="http://www.greenmart.cf/admin/products.php">View & Edit Products</a></li>
    </ul>
  </div>
  <a href="http://www.greenmart.cf/admin/customers.php" class="list-group-item admenu" style="color: #D6DBDF; border: 0px solid black;" >Customers</a>
  <div class="dropdown">
    <a href="#" class="list-group-item ropdown-toggle admenu" style="color: #D6DBDF; border: 0px solid black;" data-toggle="dropdown" >Registration<span class="caret" style="float: right;"></span></a>
    <ul class="dropdown-menu" style="width: 100%;">
      <li class="text-right"><a href="http://www.greenmart.cf/admin/register_sub.php">Staff Registration</a></li>
      <li class="text-right"><a href="http://www.greenmart.cf/admin/register_dil.php">Delivery Registration</a></li>
    </ul>
  </div>
  <a href="http://www.greenmart.cf/admin/all_delivery_loc.php" class="list-group-item admenu" style="color: #D6DBDF; border: 0px solid black;" >Delivery Service</a>
  <a href="http://www.greenmart.cf/admin/report.php" class="list-group-item admenu" style="color: #D6DBDF; border: 0px solid black;" >Sales Report</a>
  <a href="ad_logout.php" class="list-group-item admenu hidden-sm hidden-md hidden-lg" style="color: #D6DBDF; border: 0px solid black;">Sign out <span class="glyphicon glyphicon-log-out"></span></a>
  
</div>
  
</div>

<div class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
   <a href="#" class="navbar-brand" style="padding: 0; margin: 0;"><?php echo '<img class="img-responsive" style="max-height: 45px; max-width: 45px; border-radius: 60px; margin: 2px 0px 2px 20px;" src="data:image/jpeg;base64,'.base64_encode( $row1['img'] ).'"/>'; ?></a>
  <a href="http://www.greenmart.cf/admin/profile.php"><?php echo "{$row1['l_name']}"; ?></a>
  <span class="glyphicon glyphicon-menu-hamburger" style="padding-right: 0px; margin-right: 0px;" id="tob"></span>
  
   <a href="ad_logout.php" class="navbar-link pull-right hidden-xs" style="margin-top: 15px;">Sign out <span class="glyphicon glyphicon-log-out"></span></a>
   
  </div>

</div><!--end navbar and sidebar-->
