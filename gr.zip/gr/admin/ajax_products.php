<?php session_start(); ?>
<?php require_once('../inc/sql_con.php'); ?>
<?php 
	if (isset($_GET['opt']) && $_GET['opt']=="ps") { //search
		$sql="SELECT * FROM products WHERE id LIKE '%{$_GET['sv']}%' OR p_name LIKE '%{$_GET['sv']}%' OR 
		p_dis LIKE '%{$_GET['sv']}%' ";
	}
	else if(isset($_GET['opt']) && $_GET['opt']="p" || $_GET['sv']=="")//onload ro empty search value
	{
		$sql="SELECT * FROM products";
	}
	$res=mysqli_query($con, $sql);
		while ($row=mysqli_fetch_assoc($res)) 
		{
			echo '
		<div class="row text-center" style="border: 1px solid #D5D8DC; border-radius: 7px;">
		<div class="col-md-2">
		<img class="img-responsive" style="max-width: 100px; max-height:100px; float: left;" src="data:image/jpeg;base64,'.base64_encode( $row['img'] ).'"/>
		</div>
		<div class="col-md-1">
		<h6 class="text-left hidden-md hidden-lg">ID:</h6><p>'.$row['id'].'</p>
		</div>
		<div class="col-md-1">
		<h6 class="text-left hidden-md hidden-lg">NAME:</h6><p>'.$row['p_name'].'</p>
		</div>
        <div class="col-md-3" style="max-height:100px; overflow-y:scroll;">
        <h6 class="text-left hidden-md hidden-lg">DISCRIPTION:</h6><p>'.$row['p_dis'].'</p>
        </div>
        <div class="col-md-1">
        <h6 class="text-left hidden-md hidden-lg">PRICE:</h6><p>'.$row['p_price'].'</p>
        </div>
        <div class="col-md-2">
        <h6 class="text-left hidden-md hidden-lg">QTY:</h6><p>'.$row['qty'].'</p>
        </div>
        <div class="col-md-2">
        <a href="http://www.greenmart.cf/admin/edit_product.php?pid='.$row['id'].'" class="btn btn-default" style="width:100%;">Edit<i class="fa fa-pencil-square-o pull-right" aria-hidden="true"></i></a >
        </div>
    </div>
    <br>
		';
}
 ?>