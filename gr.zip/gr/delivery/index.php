<?php require_once('../inc/sql_con.php'); ?>
<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
?>
<?php 
    if (!isset($_SESSION["uidd"])) {
      header('LOCATION:http://www.greenmart.cf/login.php');
    }
 ?>
 <?php 
      if (isset($_POST['conorder'])) {
          $sqlup="UPDATE delivery SET status=0,cus_lat=NULL,cus_lon=NULL WHERE id='{$_SESSION["uidd"]}'";
          $resup=mysqli_query($con, $sqlup);
          echo "<script>alert('delivery completed!')</script>";
      }
  ?>
<?php 
      $sql="SELECT * FROM delivery WHERE id='{$_SESSION["uidd"]}'";
      $res=mysqli_query($con, $sql);
      $row=mysqli_fetch_assoc($res);
 ?>
 
<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/main.css">
    <link rel="shortcut icon" href="../img/Artdesigner-Urban-Stories-Cart.ico" />
    <script src="../bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/main.js"></script>
<head>
	<meta charset="UTF-8">
	<title>Marker Clustering</title>
	<!-- <meta http-equiv="refresh" content="10; url=up_de_loc.php"> -->
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        min-height: 500px;
        max-height: 700px;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #wdg
      {
        position: absolute;
        z-index: 1000;
        bottom: 10px;
        opacity: 0.8;
        position: fixed;
        left: 15px;
      }
      #wdg:hover
      {
        opacity: 1;

      }
      #conorder:hover
      {
        opacity: 1;

      }
      #conorder{
        position: absolute;
        z-index: 1000;
        bottom: 10px;
        opacity: 0.8;
        position: fixed;
        right: 15px;

      }
    </style>
</head>
<body onload="getLocation()">
	<script>
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition);
    } else { 
        document.getElementById('ind').innerHTML="location not updating....";
    }
  setTimeout("getLocation()",2000);
}

function showPosition(position) {
    
    xmlhttp = new XMLHttpRequest();
			xmlhttp.open("GET","ajax_location.php?lat="+position.coords.latitude+"&lon="+position.coords.longitude+"&opt=up",false);
        	xmlhttp.send(null);
        	//alert(xmlhttp.responseText);
        	document.getElementById('ind').innerHTML=xmlhttp.responseText;
          

}
</script>
<div class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div id="ind" class="btn btn-default nav navbar-nav" style="position: absolute; z-index: 1000; top: 5px; opacity: 0.8; position: fixed;">location error!</div>
  <a href="d_logout.php" class="navbar-link pull-right" style="margin-top: 15px;">Sign out <span class="glyphicon glyphicon-log-out"></span></a>
  </div>
</div>
<a href="index.php" id="wdg" class="btn btn-danger">current possition</a>
<form action="" method="post">
  <button id="conorder" name="conorder" class="btn btn-success">delivery completed</button>
</form>
<div class="container">
  <br clear="all"><br clear="all"><br clear="all"><br clear="all">
    <div id="map" class="col-xs-12"></div>
  
</div>
    <script>
      function mymap() {
        var deliverym = {lat: <?php echo "{$row['loc_lat']}"; ?>, lng: <?php echo "{$row['loc_lon']}"; ?>};
        var customerm = {lat: <?php echo "{$row['cus_lat']}"; ?>, lng: <?php echo "{$row['cus_lon']}"; ?>};
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 13,
          center: customerm
        });
         var directionsDisplay = new google.maps.DirectionsRenderer({
          map: map,
          suppressMarkers: true//hidden direction markers
        });
         var request = {
          destination: deliverym,
          origin: customerm,
          travelMode: 'DRIVING'
        };
         map.setOptions({ minZoom: 11, maxZoom: 16 });
        var marker = new google.maps.Marker({ // deliery loc
          position: deliverym,
          map: map,
          icon: '../img/truck_delivery_logistics_transportation_shipping_deliver_shipment_v3-128.png'
        });

        var marker = new google.maps.Marker({ //customer loc
          position: customerm,
          map: map,
          icon: '../img/34343.png'
        });

        var directionsService = new google.maps.DirectionsService();
        directionsService.route(request, function(response, status) {
          if (status == 'OK') {
            // Display the route on the map.
            directionsDisplay.setDirections(response);
          }
        });
      }
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY&callback=mymap"
        async defer></script>

        
<script>
       (function(){
        $(function(){//this for display new orders
          
          $("#ind").fadeToggle();    
        });
    setTimeout(arguments.callee, 2000);//calling every 10sec
})();   
</script>
  </body>
</html>