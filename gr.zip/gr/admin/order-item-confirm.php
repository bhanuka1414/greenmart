<?php session_start(); ?>
<?php require_once('../inc/sql_con.php'); ?>
<?php 
    if (isset($_GET['orid-c'])) {
        

        $sql="SELECT tmp_lat,tmp_lon FROM orders WHERE order_id={$_GET['orid-c']}";
        $res=mysqli_query($con, $sql);
        $row=mysqli_fetch_assoc($res);

        $sqlup="UPDATE delivery SET cus_lat='{$row['tmp_lat']}',cus_lon='{$row['tmp_lon']}',status=1,order_id={$_GET['orid-c']}
        WHERE id='{$_GET['delivery']}'";
        $resup=mysqli_query($con, $sqlup);
        if ($resup) {
            $sql="UPDATE orders SET confirm=1 WHERE order_id={$_GET['orid-c']}";
            $res=mysqli_query($con, $sql);
            header('LOCATION:http://www.greenmart.cf/admin/');
        }
        else
        {
            echo "<script>alert('error!')</script>";
        } 
    }
 ?>
<?php 
    
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/main.css">
    <link rel="shortcut icon" href="../img/Artdesigner-Urban-Stories-Cart.ico" />
    <script src="../bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/main.js"></script>
	<title>Admin</title>
	<style>
@media screen and (max-width: 750px)
{
    
    body { padding-top: 0px; }
   
}
body { padding-top: 0px; }

    </style>
</head>
<body>
<?php require_once('../inc/admin_tmp.php'); ?>
<br><br>
<div class="container">
<center><h3>ORDER NO : <?php echo "{$_GET['orid']}"; ?></h3></center>
	<div class="row text-center hidden-xs hidden-sm" style="border-bottom: 1px solid black;"><hr>
		<div class="col-md-7">
            <h5>ITEM</h5>
        </div>
        <div class="col-md-2">
            <h5>QTY</h5>
        </div>
        <div class="col-md-3">
            <h5>PRICE</h5>
        </div>
	</div>
    <br>
<?php 
        $sql="SELECT * FROM order_item WHERE order_id={$_GET['orid']}";
        $res=mysqli_query($con, $sql);
        while ($row1=mysqli_fetch_assoc($res))
        {
            $sq2="SELECT * FROM products WHERE  id={$row1['item_id']}";
            $res2=mysqli_query($con, $sq2);
            $row2=mysqli_fetch_assoc($res2);
     ?>
    <div class="row text-center" style="border: 1px solid #D5D8DC; border-radius: 7px;">
        <div class="col-md-7">
            <span><?php echo '<img class="img-responsive hidden-xs" style="max-width: 100px; max-height:100px; float: left;" src="data:image/jpeg;base64,'.base64_encode( $row2['img'] ).'"/>'; ?></span>
            <span class="hidden-xs" style="max-width: 100%; display: block; overflow-y: scroll; max-height: 100px;">
        <?php echo "{$row2['p_dis']}"; ?></span>
        <p class="hidden-lg hidden-md hidden-sm"><?php echo "{$row2['p_name']}"; ?></p>
        </div>
        <div class="col-md-2">
            <h6 class="text-left hidden-md hidden-lg">QTY:</h6><p><?php echo "{$row1['qty']}"; ?></p>
        </div>
        <div class="col-md-3">
            <h6 class="text-left hidden-md hidden-lg">PRICE:</h6><p><?php echo "{$row1['qty']}"; ?> x <?php echo "{$row2['p_price']}"; ?> <span class="glyphicon glyphicon-triangle-right"></span> RS <?php echo "{$row1['price']}"; ?>.</p>
        </div>
    </div>
    <br>
<?php } ?>
        <div class="row">
            <div class="col-md-offset-7 col-md-5 col-sm-offset-7 col-sm-5">
        <?php if (isset($_GET['co']) && $_GET['co']==1) { ?><!--confirmed orders show back button-->
        <a href="http://www.greenmart.cf/admin/confirmed-orders.php" class="btn btn-default pull-right">
        <span class="glyphicon glyphicon-arrow-left"></span> back</a>
        <?php }else{ ?><!--new orders show back confirm button and delivery select-->
                <form action="" method="GET">
                    <div class="form-group">
                        <label for="sel1">Select list (select one):</label>
                        <select class="form-control" id="sel1" name="delivery" required>
                            <option value="">None</option>
                            <?php 
                                $sql="SELECT id,f_name FROM delivery WHERE status=0";
                                $res=mysqli_query($con, $sql);
                                while ($row=mysqli_fetch_assoc($res)) {
                             ?>
                            <option value="<?php echo "{$row['id']}"; ?>">
                            <?php echo "{$row['f_name']}"; ?>(<?php echo "{$row['id']}"; ?>)</option>
                            <?php } ?>
                        </select>
                                        
                    </div>
                    <input type="hidden" name="orid-c" value="<?php echo "{$_GET['orid']}"; ?>">
                    <button class="btn btn-primary">confirm Order</button>
                </form>
        <?php } ?>
        </div>      
        </div>
</div>
</body>
</html>
        
