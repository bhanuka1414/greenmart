<?php session_start(); ?>
<?php require_once('../inc/sql_con.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/main.css">
    <link rel="shortcut icon" href="../img/Artdesigner-Urban-Stories-Cart.ico" />
    <script src="../bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/main.js"></script>
	<title>Admin</title>
	<script>
    (function(){
        $(function(){//this for display new orders
            
            
                xmlhttp = new XMLHttpRequest();
                xmlhttp.open("GET","ajax_general.php?opt=new",false);
                xmlhttp.send(null);
                $('#all_orders').html(xmlhttp.responseText);
               
        });
    setTimeout(arguments.callee, 10000);//calling every 10sec
})();
        
    </script>
    <style>
@media screen and (max-width: 750px)
{
    
    body { padding-top: 0px; }
   
}
body { padding-top: 0px; }

    </style>
</head>
<body>
<?php require_once('../inc/admin_tmp.php'); ?>
<br><br>
<div class="container">
<center><h3>New Orders</h3></center>
	<div class="row text-center hidden-xs hidden-sm" style="border-bottom: 1px solid black;"><hr>
		<div class="col-md-2">
            <h5>Order No</h5>
        </div>
        <div class="col-md-2">
            <h5>Date - Time</h5>
        </div>
        <div class="col-md-1">
            <h5>Total Amount</h5>
        </div>
        <div class="col-md-2">
            <h5>Address</h5>
        </div>
        <div class="col-md-1">
            <h5>Phone NO</h5>
        </div>
        <div class="col-md-2">
            <h5>Name</h5>
        </div>
        <div class="col-md-2">
            <h5>Action</h5>
        </div>
	</div>
    <br>
<div id="all_orders"></div>
</div>
</body>
</html>

