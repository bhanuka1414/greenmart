<button id="show-menu" class="btn btn-default hidden-lg hidden-md" style="width: 100%;"><span class="glyphicon glyphicon-menu-hamburger"></span>catogaries</button>
<div id="menu-lg" class="" style="position: relative;">
            <div id="menu-dsk" class="btn-group btn-group-justified" style="width: 100%;">
                <div class="btn-group">
                    <a href="http://www.greenmart.cf/cat/household" class="btn btn-default house">Household</a>
                </div>
                <div class="btn-group">
                    <a href="http://www.greenmart.cf/cat/liquor" class="btn btn-default lqr">Liquor</a>
                </div>
                <div class="btn-group">
                    <a href="http://www.greenmart.cf/cat/bakery" class="btn btn-default bek">Bakery</a>
                </div>
                <div class="btn-group">
                    <a href="http://www.greenmart.cf/cat/grocery" class="btn btn-default gro">Grocery</a>
                </div>
                <div class="btn-group">
                    <a href="http://www.greenmart.cf/cat/drinks" class="btn btn-default drinks">Drinks</a>
                </div>
                <div class="btn-group">
                    <a href="http://www.greenmart.cf/cat/desserts" class="btn btn-default des">Desserts</a>
                </div>
                <div class="btn-group">
                    <a href="http://www.greenmart.cf/cat/vegetables" class="btn btn-default veg">Vegetables</a>
                </div>
                <div class="btn-group">
                    <a href="http://www.greenmart.cf/cat/meat" class="btn btn-default meat">Meat</a>
                </div>
                <div class="btn-group">
                    <a href="http://www.greenmart.cf/cat/fish" class="btn btn-default fish">Fish</a>
                </div>
                <div class="btn-group">
                    <a href="http://www.greenmart.cf/cat/homeware" class="btn btn-default home">Homeware</a>
                </div>
                <div class="btn-group">
                    <a href="http://www.greenmart.cf/cat/fruits" class="btn btn-default fruit">Fruits</a>
                </div>
            </div>
            <script>
                $(function(){
                    if ($(window).width() <= 992) {
                            $('#menu-dsk').addClass('btn-group-vertical hidden-xs hidden-sm');
                            $('#menu-dsk').removeClass('btn-group-justified');

                            $('#show-menu').click(function(){
                                $('#menu-dsk').toggleClass('hidden-xs hidden-sm');
                            });

                        } 
                        else {
                            $('#menu-dsk').addClass('btn-group-justified');
                            $('#menu-dsk').removeClass('btn-group-vertical');
                        }
                });
            </script>
           
        </div>