<?php session_start(); ?>
<?php require_once('inc/sql_con.php'); ?>
<?php 
	
			$sql="UPDATE user SET loc_lat={$_GET['lat']} , loc_lon={$_GET['lon']} WHERE id={$_SESSION["uid"]}";
			$res=mysqli_query($con, $sql);
			if ($res) {
				echo "update your Home location";
			}
			else
			{
				echo "check location(gps) error";
			}
		
 ?>