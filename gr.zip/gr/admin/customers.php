<?php session_start(); ?>
<?php require_once('../inc/sql_con.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/main.css">
    <link rel="shortcut icon" href="../img/Artdesigner-Urban-Stories-Cart.ico" />
    <script src="../bootstrap/js/jquery-3.1.1.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
    <script src="../bootstrap/js/main.js"></script>
	<title>Admin</title>
	<script>
    
        $(function(){
            
                $('#seaechb').click(function(){ // display search products 
                    xmlhttp = new XMLHttpRequest();
                    var sv1=$('#sv').val();
                    xmlhttp.open("GET","ajax_cus.php?opt=cs&sv="+sv1,false);
                    xmlhttp.send(null);
                $('#all_orders').html(xmlhttp.responseText);
                });
                xmlhttp = new XMLHttpRequest(); //display all products
                xmlhttp.open("GET","ajax_cus.php?opt=c",false);
                xmlhttp.send(null);
                $('#all_orders').html(xmlhttp.responseText);
               
        });

        
    </script>
    <style>
@media screen and (max-width: 750px)
{
    
    body { padding-top: 0px; }
   
}
body { padding-top: 0px; }

    </style>
</head>
<body>
<?php require_once('../inc/admin_tmp.php'); ?>
<br><br>
<div class="container">
<center><h3>CUSTOMERS DETAILS</h3></center>
<form class="form-search" method="get" id="s" action="">
    <div class="input-append">
        <input  style="width: 230px;" type="search" class="input-medium search-query" name="sv" id="sv" placeholder="Search" value="">
        <button type="button" class="add-on" name="seaech" id="seaechb"><i class="glyphicon glyphicon-search"></i></button>
    </div>
</form>
	<div class="row text-center hidden-xs hidden-sm" style="border-bottom: 1px solid black;"><hr>
		<div class="col-md-1">
            <h5>ID</h5>
        </div>
        <div class="col-md-2">
            <h5>FIRST NAME</h5>
        </div>
        <div class="col-md-2">
            <h5>LAST NAME</h5>
        </div>
        <div class="col-md-1">
            <h5>GENDER</h5>
        </div>
        <div class="col-md-2">
            <h5>ADDRESS</h5>
        </div>
        <div class="col-md-2">
            <h5>E-mail</h5>
        </div>
        <div class="col-md-2">
            <h5>PHONE NO</h5>
        </div>
	</div>
    <br>
<div id="all_orders"></div><!--ajax response-->
</div>
</body>
</html>

